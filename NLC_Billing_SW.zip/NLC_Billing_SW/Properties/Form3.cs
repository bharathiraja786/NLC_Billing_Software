﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace NLC_SMS
{
    public partial class Form3 : Form
    {
       // SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-7RUQB76;Initial Catalog=ABB;Integrated Security=True;Pooling=False");
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["NLC_SMS.Properties.Settings.abbConnectionString"].ConnectionString);
       
        public Form3( string val)
        {
            InitializeComponent();
            label1.Text = val;
          
            
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
               
                if (label1.Text != "ADMIN")
                {
                    SqlDataAdapter sda = new SqlDataAdapter("SELECT SL_NO as [SERIAL NUMBER],M_CODE as [MATERIAL CODE],MATERIAL_DESCRIPTION as [MATERIAL DESCRIPTION],UNIT,RECEIVED_QTY as[RECEIVED QUANTITY],USED_QTY as [USED QUANTITY],AVAILABLE_STOCK as [AVAILABLE STOCK] FROM ABB WHERE SL_NO!='0.1' AND SL_NO!='0.2' AND SL_NO!='0.3' AND SL_NO!='0.4' AND SL_NO!='0.5' AND SL_NO!='0.6'ORDER BY SL_NO ", con);

                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;

                    foreach (DataGridViewColumn col in dataGridView1.Columns)
                    {
                        col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                        col.HeaderCell.Style.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Pixel);
                    }

                    dataGridView1.Columns[2].Width = 450;
                    dataGridView1.Columns[6].Width = 125;
                    this.dataGridView1.Columns["SERIAL NUMBER"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    this.dataGridView1.Columns["MATERIAL CODE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    this.dataGridView1.Columns["RECEIVED QUANTITY"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    this.dataGridView1.Columns["USED QUANTITY"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    this.dataGridView1.Columns["AVAILABLE STOCK"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    this.dataGridView1.Columns["UNIT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                    this.dataGridView1.Columns["MATERIAL DESCRIPTION"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;           




                    button1.Enabled = false;
                    button8.Enabled = false;
                    button9.Enabled = false;
                    button11.Enabled = false;
                    button12.Enabled = false;
                    button10.Enabled = false;
                    button13.Enabled = false;
                    button14.Enabled = false;
                    button15.Enabled = false;                   
                    button17.Enabled = false;
                }
                else
                {
                    SqlDataAdapter sda = new SqlDataAdapter("SELECT SL_NO as [SERIAL NUMBER],M_CODE as [MATERIAL CODE],MATERIAL_DESCRIPTION as [MATERIAL DESCRIPTION],UNIT,RECEIVED_QTY as[RECEIVED QUANTITY],USED_QTY as [USED QUANTITY],AVAILABLE_STOCK as [AVAILABLE STOCK] FROM ABB WHERE SL_NO!='0.1' AND SL_NO!='0.2' AND SL_NO!='0.3' AND SL_NO!='0.4' AND SL_NO!='0.5' AND SL_NO!='0.6'ORDER BY SL_NO ", con);

                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;

                    foreach (DataGridViewColumn col in dataGridView1.Columns)
                    {
                        col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                        col.HeaderCell.Style.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Pixel);
                    }

                    dataGridView1.Columns[2].Width = 450;
                    dataGridView1.Columns[6].Width = 125;
                    this.dataGridView1.Columns["SERIAL NUMBER"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    this.dataGridView1.Columns["MATERIAL CODE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    this.dataGridView1.Columns["RECEIVED QUANTITY"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    this.dataGridView1.Columns["USED QUANTITY"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    this.dataGridView1.Columns["AVAILABLE STOCK"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    this.dataGridView1.Columns["UNIT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                    this.dataGridView1.Columns["MATERIAL DESCRIPTION"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;           

                }
                Cursor.Current = Cursors.Default;
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(),"ERROR",MessageBoxButtons.OK,MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set ACTIONS+=', CREATE_INVOICE' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
            this.Hide();
            Form4 frm4 = new Form4();
            frm4.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set LOGOUT_DT='" + dateTimePicker1.Value.ToString("yyyy-MM-dd HH:mm:ss")+"',ACTIONS+=', LOGGED_OUT' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();

            this.Hide();
            Form1 frm1 = new Form1();
            frm1.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set LOGOUT_DT='" + dateTimePicker1.Value.ToString("yyyy-MM-dd HH:mm:ss") + "',ACTIONS+=', EXITED' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
                
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set ACTIONS+=', REQ_MATERIALS' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
            this.Hide();
            Form6 frm6 = new Form6(label1.Text);
            frm6.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set ACTIONS+=', RET_MATERIALS' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
                this.Hide();
                Form7 frm7 = new Form7(label1.Text);
                frm7.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set ACTIONS+=', TRANS_HISTORY' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
            this.Hide();
            Form8 frm8 = new Form8(label1.Text);
            frm8.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set ACTIONS+=', UPDATE_INVOICE' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
            Form9 frm9 = new Form9();
            frm9.Show();
            this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set ACTIONS+=', TO_EXCEL' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
                
            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
            // creating new WorkBook within Excel application  
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            // creating new Excelsheet in workbook  
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            // see the excel sheet behind the program  
            app.Columns.ColumnWidth = 12;
            app.Visible = true;
            // get the reference of first sheet. By default its name is Sheet1.  
            // store its reference to worksheet  
            worksheet = workbook.Sheets["Sheet1"];
            worksheet = workbook.ActiveSheet;
            // changing the name of active sheet  
            worksheet.Name = "AVAILABLE STOCKS";
            // storing header part in Excel  
            for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)
            {
                worksheet.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;
            }
            // storing Each row and column value to excel sheet  
            for (int i = 0; i <= dataGridView1.Rows.Count - 1; i++)
            {
                for (int j = 0; j < dataGridView1.Columns.Count; j++)
                {
                    worksheet.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                }
            }
            Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set ACTIONS+=', VIEW_INVOICE' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
            this.Hide();
            Form10 FRM10 = new Form10();
            FRM10.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void BT_KD1(object sender, KeyEventArgs e)
        {
           
        }

        private void bt_kp1(object sender, KeyPressEventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set ACTIONS+=', ADD_MATERIALS' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
            this.Hide();
            Form11 frm11 = new Form11();
            frm11.Show();
        }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set ACTIONS+=', BACKUP & RESTORE' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
            this.Hide();
            Form12 FRM12 = new Form12(label1.Text);
            FRM12.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }

        }

        private void button12_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set ACTIONS+=', CHANGE_ADMIN_PASSWORD' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
                this.Hide();
                Form13 frm = new Form13();
                frm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }

        }

       
        private void button13_Click_1(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set ACTIONS+=', INVOICE_FILE_UP & DOWN' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
                this.Hide();
                Form15 frm = new Form15();
                frm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set ACTIONS+=', EDIT_MATERIALS' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
                this.Hide();
                Form14 frm = new Form14();
                frm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }

        }

        private void button15_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set ACTIONS+=', USER_SETTINGS' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
                this.Hide();
                Form2 frm = new Form2();
                frm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set ACTIONS+=', MACHINE_WORKLOAD' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
                this.Hide();
                Form17 frm = new Form17(label1.Text);
                frm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set ACTIONS+=', LOGIN_HISTORY' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
                this.Hide();
                Form16 frm = new Form16();
                frm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }

        }



    }
}
