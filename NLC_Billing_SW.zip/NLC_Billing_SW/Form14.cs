﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace NLC_SMS
{
    public partial class Form14 : Form
    {
       // SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-7RUQB76;Initial Catalog=ABB;Integrated Security=True;Pooling=False");
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["NLC_SMS.Properties.Settings.abbConnectionString"].ConnectionString);
      
       
        public Form14()
        {
            InitializeComponent();
            /* , "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        , "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
         MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);   */
        }

        private void Form14_Load(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                comboBox1.Items.Clear();
                comboBox2.Items.Clear();
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT M_CODE,MATERIAL_DESCRIPTION FROM ABB WHERE SL_NO!='0.1' AND SL_NO!='0.2' AND SL_NO!='0.3' AND SL_NO!='0.4' AND SL_NO!='0.5' ORDER BY SL_NO";
                cmd.ExecuteNonQuery();/*CHANGE COLUMN NAME SL_NO TO M_CODE*/
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    comboBox1.Items.Add(dr["MATERIAL_DESCRIPTION"].ToString());
                    comboBox2.Items.Add(dr["M_CODE"].ToString());//SL_NO TO M_CODE
                }
                con.Close();
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
               
                comboBox1.Items.Clear();
                comboBox2.Items.Clear();
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT M_CODE,MATERIAL_DESCRIPTION FROM ABB WHERE SL_NO!='0.1' AND SL_NO!='0.2' AND SL_NO!='0.3' AND SL_NO!='0.4' AND SL_NO!='0.5' ORDER BY SL_NO";
                cmd.ExecuteNonQuery();/*CHANGE COLUMN NAME SL_NO TO M_CODE*/
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    comboBox1.Items.Add(dr["MATERIAL_DESCRIPTION"].ToString());
                    comboBox2.Items.Add(dr["M_CODE"].ToString());//SL_NO TO M_CODE
                }
                con.Close();
                Cursor.Current = Cursors.Default;
               
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();               
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                comboBox1.SelectedIndex = 0;
                comboBox2.SelectedIndex = 0;
                comboBox1.Focus();
                Cursor.Current = Cursors.Default;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
               
                con.Open();
                if (comboBox1.SelectedIndex == -1 )
                {
                    MessageBox.Show("PLEASE SELECT MATERIAL_DESCRIPTION", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    comboBox1.Focus();
                }
                else if (comboBox2.SelectedIndex == -1 )
                {
                    MessageBox.Show("PLEASE SELECT MATERIAL_CODE", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    comboBox2.Focus();
                }
                else
                {
                    if (textBox1.Text != "" & textBox2.Text != "" & textBox3.Text != "")
                    {
                        SqlCommand cmd = con.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "update ABB set MATERIAL_DESCRIPTION='" + textBox1.Text + "',m_code='" + textBox2.Text + "',unit='" + textBox3.Text + "' where MATERIAL_DESCRIPTION ='" + comboBox1.Text + "' ";
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("UPDATED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    else if (textBox1.Text != "" & textBox2.Text != "" )
                    {
                        SqlCommand cmd = con.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "update ABB set MATERIAL_DESCRIPTION='" + textBox1.Text + "',m_code='" + textBox2.Text + "' where MATERIAL_DESCRIPTION ='" + comboBox1.Text + "' ";
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("UPDATED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else if (textBox1.Text != "" & textBox3.Text != "")
                    {
                        SqlCommand cmd = con.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "update ABB set MATERIAL_DESCRIPTION='" + textBox1.Text + "',unit='" + textBox3.Text + "' where MATERIAL_DESCRIPTION ='" + comboBox1.Text + "' ";
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("UPDATED SUCCESSFULLY");
                    }
                    else if ( textBox2.Text != "" & textBox3.Text != "")
                    {
                        SqlCommand cmd = con.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "update ABB set m_code='" + textBox2.Text + "',unit='" + textBox3.Text + "' where MATERIAL_DESCRIPTION ='" + comboBox1.Text + "' ";
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("UPDATED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else if (textBox1.Text != "")
                    {
                        SqlCommand cmd = con.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "update ABB set MATERIAL_DESCRIPTION='" + textBox1.Text + "' where MATERIAL_DESCRIPTION ='" + comboBox1.Text + "' ";
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("UPDATED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else if (textBox2.Text != "")
                    {
                        SqlCommand cmd = con.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "update ABB set m_code='" + textBox2.Text + "' where MATERIAL_DESCRIPTION ='" + comboBox1.Text + "' ";
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("UPDATED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else if (textBox3.Text != "")
                    {
                        SqlCommand cmd = con.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "update ABB set unit='" + textBox3.Text + "' where MATERIAL_DESCRIPTION ='" + comboBox1.Text + "' ";
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("UPDATED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show(" UNABLE TO UPDATE EMPTY VALUES", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    con.Close();

                }
                Cursor.Current = Cursors.Default;
               
            }
            catch (Exception ex)
            {
               // MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                comboBox1.SelectedIndex = -1;
                comboBox2.SelectedIndex = -1;
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                Cursor.Current = Cursors.Default;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
               
                if (comboBox1.SelectedIndex != 0)
                {
                    comboBox2.Items.Clear();
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "select M_CODE from ABB where MATERIAL_DESCRIPTION='" + comboBox1.SelectedItem.ToString() + "' ";//SL_NO TO M_CODE
                    cmd.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);

                    foreach (DataRow dr in dt.Rows)
                    {
                        comboBox2.Items.Add(dr["M_CODE"].ToString());//SL_NO TO M_CODE
                        comboBox2.SelectedIndex = 0;
                    }
                    con.Close();
                
                }
                Cursor.Current = Cursors.Default;
               
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
               
                if (comboBox2.SelectedIndex != 0)
                {
                    comboBox1.Items.Clear();
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "select MATERIAL_DESCRIPTION from ABB where M_CODE='" + comboBox2.SelectedItem.ToString() + "' ";// SL_NO TO M_CODE
                    cmd.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);

                    foreach (DataRow dr in dt.Rows)
                    {

                        comboBox1.Items.Add(dr["MATERIAL_DESCRIPTION"].ToString());
                        comboBox1.SelectedIndex = 0;
                    }
                    con.Close();


                }
                Cursor.Current = Cursors.Default;
               
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                Form3 frm3 = new Form3("ADMIN");
                frm3.Show();
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
            }
        }

        private void tb_kd1(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    textBox2.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { }
        }

        private void tb_kd2(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    textBox3.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { }
        }

        private void tb_kd3(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    button1.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.CharacterCasing = CharacterCasing.Upper;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.CharacterCasing = CharacterCasing.Upper;
        }
    }
   

       
              
}
