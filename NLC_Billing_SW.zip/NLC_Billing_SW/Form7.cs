﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Configuration;

namespace NLC_SMS
{
    public partial class Form7 : Form
    {
        //SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-7RUQB76;Initial Catalog=ABB;Integrated Security=True;Pooling=False");
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["NLC_SMS.Properties.Settings.abbConnectionString"].ConnectionString);
      
        public Form7(string value)
        {
            InitializeComponent();
            label8.Text = value;
            textBox1.Text = value;

           /* , "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            , "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
             MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);   */
        }


        private void Form7_Load(object sender, EventArgs e)
        {
            
            try
            {
                Cursor.Current = Cursors.WaitCursor;
               
                comboBox3.Items.Clear();
                comboBox2.Items.Clear();
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT M_CODE,MATERIAL_DESCRIPTION FROM ABB WHERE SL_NO!='0.1' AND SL_NO!='0.2' AND SL_NO!='0.3' AND SL_NO!='0.4' AND SL_NO!='0.5' ORDER BY SL_NO";
                cmd.ExecuteNonQuery();/*CHANGE COLUMN NAME SL_NO TO M_CODE*/
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    comboBox2.Items.Add(dr["MATERIAL_DESCRIPTION"].ToString());
                    comboBox3.Items.Add(dr["M_CODE"].ToString());//SL_NO TO M_CODE
                }
                con.Close();

                comboBox1.Items.Clear();
                con.Open();
                SqlCommand cmd1 = new SqlCommand();
                cmd1 = con.CreateCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "select * from MACHINES WHERE MACHINE_ID!='ADD_NEW_MACHINE'";
                cmd1.ExecuteNonQuery();
                DataTable dt1 = new DataTable();
                SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
                sda1.Fill(dt1);
                foreach (DataRow dr in dt1.Rows)
                {
                    comboBox1.Items.Add(dr["MACHINE_ID"].ToString());
                }
                Cursor.Current = Cursors.Default;
               
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
                
            }
            finally 
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }



        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                if (comboBox1.SelectedIndex == -1)
                {
                    MessageBox.Show("PLEASE SELECT MACHINE_ID", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    comboBox1.Focus();
                }
                else if (comboBox2.SelectedIndex == -1 | comboBox2.Text=="")
                {
                    MessageBox.Show("PLEASE SELECT MATERIAL_DESCRIPTION", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    comboBox2.Focus();
                }
                else if (comboBox3.SelectedIndex == -1 | comboBox3.Text=="")
                {
                    MessageBox.Show("PLEASE SELECT MATERIAL_CODE", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    comboBox3.Focus();
                }
                else if (textBox4.Text == "")
                {
                    MessageBox.Show("PLEASE ENTER MATERIAL_QUANTITY", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox4.Focus();
                }
                else
                {

                    double a, b;
                    double.TryParse(textBox5.Text, out a);
                    double.TryParse(textBox4.Text, out b);
                    if (textBox5.Text != "")
                    {
                        if (a >= b)
                        {
                            con.Open();
                            SqlCommand cmd1 = con.CreateCommand();
                            cmd1.CommandType = CommandType.Text;
                            cmd1.CommandText = "insert into history values('" + textBox1.Text + "','" + comboBox1.SelectedItem.ToString() + "','" + comboBox2.SelectedItem.ToString() + "','" + comboBox3.SelectedItem.ToString() + "','" + textBox4.Text + "','" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "','RETURN')";
                            cmd1.ExecuteNonQuery();
                           

                            SqlCommand cmd = con.CreateCommand();
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandText = "update ABB set AVAILABLE_STOCK=(AVAILABLE_STOCK+'" + textBox4.Text + "') where MATERIAL_DESCRIPTION='" + comboBox2.SelectedItem.ToString() + "' ";
                            cmd.ExecuteNonQuery();
                           // MessageBox.Show("ADD AT AS sucess");

                            SqlCommand cmd3 = con.CreateCommand();
                            cmd3.CommandType = CommandType.Text;
                            cmd3.CommandText = "update ABB set USED_QTY-='" + textBox4.Text + "' where MATERIAL_DESCRIPTION='" + comboBox2.SelectedItem.ToString() + "' ";
                            cmd3.ExecuteNonQuery();
                           // MessageBox.Show("SUB UQ sucess");
                            MessageBox.Show("RETURN ACCEPTED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);


                        }
                        else
                            MessageBox.Show("RETURN MATERIAL NOT ACCEPTED", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                        MessageBox.Show("PLEASE CHECK SELECTED RETURN MATERIAL", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    con.Close();

                }
                Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
               con.Close();
               // textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                comboBox1.SelectedIndex = -1;
                comboBox2.SelectedIndex = -1;
                comboBox3.SelectedIndex = -1;
                comboBox3.Text = "";

                dateTimePicker1.Value = DateTime.Now;
                textBox1.Focus();
                Cursor.Current = Cursors.Default;
           
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                Form3 frm3 = new Form3(label8.Text);
                frm3.Show();
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            finally
            {
                
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
               
                if (comboBox2.SelectedIndex != 0)
                {
                    comboBox3.Items.Clear();
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "select M_CODE from ABB where MATERIAL_DESCRIPTION='" + comboBox2.Text + "' ";//SL_NO TO M_CODE
                    cmd.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);

                    foreach (DataRow dr in dt.Rows)
                    {
                        comboBox3.Items.Add(dr["M_CODE"].ToString());//SL_NO TO M_CODE
                        comboBox3.SelectedIndex = 0;
                    }
                    con.Close();

                    con.Open();
                    SqlCommand cmd1 = new SqlCommand();
                    cmd1 = con.CreateCommand();
                    cmd1.CommandType = CommandType.Text;
                    cmd1.CommandText = "select USED_QTY from ABB where MATERIAL_DESCRIPTION='" + comboBox2.Text + "' ";
                    cmd1.ExecuteNonQuery();
                    DataTable dt1 = new DataTable();
                    SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
                    sda1.Fill(dt1);
                    foreach (DataRow dr1 in dt1.Rows)
                    {
                        textBox5.Text = dr1["USED_QTY"].ToString();
                    }
                    //MessageBox.Show(textBox5.Text);
                    con.Close();
                }
                Cursor.Current = Cursors.Default;
               
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }

            finally 
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
               
            if (comboBox3.SelectedIndex != 0)
            {
                comboBox2.Items.Clear();
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select MATERIAL_DESCRIPTION from ABB where M_CODE='" + comboBox3.Text + "' ";// SL_NO TO M_CODE
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);

                foreach (DataRow dr in dt.Rows)
                {

                    comboBox2.Items.Add(dr["MATERIAL_DESCRIPTION"].ToString());
                    comboBox2.SelectedIndex = 0;
                }
                con.Close();

                con.Open();
                SqlCommand cmd1 = new SqlCommand();
                cmd1 = con.CreateCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "select USED_QTY from ABB where SL_NO='" + comboBox3.Text + "' ";// SL_NO TO M_CODE
                cmd1.ExecuteNonQuery();
                DataTable dt1 = new DataTable();
                SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
                sda1.Fill(dt1);
                foreach (DataRow dr1 in dt1.Rows)
                {
                    textBox5.Text = dr1["USED_QTY"].ToString();
                }
               // MessageBox.Show(textBox5.Text);
                con.Close();
            }
            Cursor.Current = Cursors.Default;
               
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }

            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                comboBox3.Items.Clear();
                comboBox2.Items.Clear();
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT M_CODE,MATERIAL_DESCRIPTION FROM ABB WHERE SL_NO!='0.1' AND SL_NO!='0.2' AND SL_NO!='0.3' AND SL_NO!='0.4' AND SL_NO!='0.5' ORDER BY SL_NO"; 
                cmd.ExecuteNonQuery();/*CHANGE COLUMN NAME SL_NO TO M_CODE*/
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    comboBox2.Items.Add(dr["MATERIAL_DESCRIPTION"].ToString());
                    comboBox3.Items.Add(dr["M_CODE"].ToString());//SL_NO TO M_CODE
                }
                con.Close();
                Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
               // textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                comboBox1.SelectedIndex = -1;
                comboBox2.SelectedIndex = 0;
                comboBox3.SelectedIndex = 0;
                
                dateTimePicker1.Value = DateTime.Now;
                textBox1.Focus();
                Cursor.Current = Cursors.Default;
            }
        
        }

        private void tb_kd1(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                textBox2.Focus();
            }
        }

        private void tb_kd2(object sender, EventArgs e)
        {

           
        }

        private void tb_kd2(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                comboBox1.Focus();
            }
        }

        private void cb_kd1(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                comboBox2.Focus();
            }
        }

        private void cb_kd2(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                comboBox3.Focus();
            }
        }

        private void cb_kd3(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                textBox4.Focus();
            }
        }

        private void tb_kd4(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                dateTimePicker1.Focus();
            }
        }

        private void dt_kd1(object sender, KeyEventArgs e)
        {
            button1.PerformClick();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            try
            {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox4.Text, "[^0-9]"))
            {
                MessageBox.Show("Please enter only numbers.");
                textBox4.Text = textBox4.Text.Remove(textBox4.Text.Length - 1);

            }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.CharacterCasing = CharacterCasing.Upper;
        }


    }
}
