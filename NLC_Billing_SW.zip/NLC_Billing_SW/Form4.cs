﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data.Sql;
using System.Configuration;


namespace NLC_SMS
{
    public partial class Form4 : Form
    {
        //SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-7RUQB76;Initial Catalog=ABB;Integrated Security=True;Pooling=False"); 
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["NLC_SMS.Properties.Settings.abbConnectionString"].ConnectionString);
      
        public Form4()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
            this.Hide();
            Form3 frm3 = new Form3("ADMIN");
            frm3.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
               
            }
            finally
            {
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                if (checkBox1.Checked == true)
                {
                    con.Open();
                    SqlCommand cmd7 = con.CreateCommand();
                    cmd7.CommandType = CommandType.Text;
                    cmd7.CommandText = "INSERT INTO PROJECT values('" + textBox2.Text + "') ";
                    cmd7.ExecuteNonQuery();
                    MessageBox.Show("PROJECT ADDED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();
                }
                else
                {
                    if (textBox1.Text == "")
                    {
                        MessageBox.Show("PLEASE ENTER INVOICE_NUMBER", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        textBox1.Focus();
                    }

                    else if (comboBox1.SelectedIndex == -1)
                    {
                        MessageBox.Show("PLEASE SELECT PROJECT", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        comboBox1.Focus();
                    }
                    else
                    {
                        if (comboBox1.SelectedIndex == 0)
                        {
                            if (textBox2.Text != "")
                            {
                                con.Open();
                                SqlCommand cmd = con.CreateCommand();
                                cmd.CommandType = CommandType.Text;
                                label6.Text = label5.Text + textBox1.Text;
                                cmd.CommandText = "alter table abb add " + label6.Text + " VARCHAR(50)";
                                cmd.ExecuteNonQuery();
                                con.Close();



                                con.Open();
                                SqlCommand cmd7 = con.CreateCommand();
                                cmd7.CommandType = CommandType.Text;
                                cmd7.CommandText = "INSERT INTO PROJECT values('" + textBox2.Text + "') ";
                                cmd7.ExecuteNonQuery();
                                con.Close();


                                con.Open();
                                SqlCommand cmd1 = con.CreateCommand();
                                cmd1.CommandType = CommandType.Text;
                                cmd1.CommandText = "UPDATE ABB SET  " + label6.Text + " = '" + textBox1.Text + "' where sl_no='0.1'";
                                cmd1.ExecuteNonQuery();
                                con.Close();

                                con.Open();
                                SqlCommand cmd2 = con.CreateCommand();
                                cmd2.CommandType = CommandType.Text;
                                cmd2.CommandText = "UPDATE ABB SET  " + label6.Text + " = '" + dateTimePicker1.Value.ToShortDateString() + "' where sl_no='0.2'";
                                cmd2.ExecuteNonQuery();
                                con.Close();

                                con.Open();
                                SqlCommand cmd3 = con.CreateCommand();
                                cmd3.CommandType = CommandType.Text;
                                cmd3.CommandText = "UPDATE ABB SET  " + label6.Text + " = '" + dateTimePicker2.Value.ToShortDateString() + "' where sl_no='0.3'";
                                cmd3.ExecuteNonQuery();
                                con.Close();

                                con.Open();
                                SqlCommand cmd4 = con.CreateCommand();
                                cmd4.CommandType = CommandType.Text;
                                cmd4.CommandText = "UPDATE ABB SET  " + label6.Text + " = '" + textBox4.Text + "' where sl_no='0.4'";
                                cmd4.ExecuteNonQuery();
                                con.Close();

                                con.Open();
                                SqlCommand cmd5 = con.CreateCommand();
                                cmd5.CommandType = CommandType.Text;
                                cmd5.CommandText = "UPDATE ABB SET  " + label6.Text + " = '" + textBox2.Text + "' where sl_no='0.5'";
                                cmd5.ExecuteNonQuery();
                                con.Close();

                                con.Open();
                                SqlCommand cmd6 = con.CreateCommand();
                                cmd6.CommandType = CommandType.Text;
                                cmd6.CommandText = "insert into invoice values('" + label6.Text + "','" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "','" + dateTimePicker2.Value.ToString("yyyy-MM-dd") + "','" + textBox4.Text + "','" + textBox2.Text + "',null)";
                                cmd6.ExecuteNonQuery();
                                // MessageBox.Show(" invoice updated IN INVOICE");
                                con.Close();

                                MessageBox.Show("INVOICE CREATED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                Form5 frm5 = new Form5(label6.Text);
                                frm5.Show();
                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show("PLEASE ENTER NEW PROJECT NAME", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                textBox2.Focus();
                            }
                        }
                        else
                        {
                            con.Open();
                            SqlCommand cmd = con.CreateCommand();
                            cmd.CommandType = CommandType.Text;
                            label6.Text = label5.Text + textBox1.Text;
                            cmd.CommandText = "alter table abb add " + label6.Text + " VARCHAR(50)";
                            cmd.ExecuteNonQuery();
                            con.Close();
                           


                            con.Open();
                            SqlCommand cmd1 = con.CreateCommand();
                            cmd1.CommandType = CommandType.Text;
                            cmd1.CommandText = "UPDATE ABB SET  " + label6.Text + " = '" + textBox1.Text + "' where sl_no='0.1'";
                            cmd1.ExecuteNonQuery();
                            con.Close();
                            // MessageBox.Show("INVOICE NUMBER INSERTED SUCCESSFULLY");

                            con.Open();
                            SqlCommand cmd2 = con.CreateCommand();
                            cmd2.CommandType = CommandType.Text;
                            cmd2.CommandText = "UPDATE ABB SET  " + label6.Text + " = '" + dateTimePicker1.Value.ToShortDateString() + "' where sl_no='0.2'";
                            cmd2.ExecuteNonQuery();
                            con.Close();

                            con.Open();
                            SqlCommand cmd3 = con.CreateCommand();
                            cmd3.CommandType = CommandType.Text;
                            cmd3.CommandText = "UPDATE ABB SET  " + label6.Text + " = '" + dateTimePicker2.Value.ToShortDateString() + "' where sl_no='0.3'";
                            cmd3.ExecuteNonQuery();
                            con.Close();

                            con.Open();
                            SqlCommand cmd4 = con.CreateCommand();
                            cmd4.CommandType = CommandType.Text;
                            cmd4.CommandText = "UPDATE ABB SET  " + label6.Text + " = '" + textBox4.Text + "' where sl_no='0.4'";
                            cmd4.ExecuteNonQuery();
                            con.Close();

                            con.Open();
                            SqlCommand cmd5 = con.CreateCommand();
                            cmd5.CommandType = CommandType.Text;
                            cmd5.CommandText = "UPDATE ABB SET  " + label6.Text + " = '" + comboBox1.SelectedItem + "' where sl_no='0.5'";
                            cmd5.ExecuteNonQuery();
                            con.Close();

                            con.Open();
                            SqlCommand cmd6 = con.CreateCommand();
                            cmd6.CommandType = CommandType.Text;
                            cmd6.CommandText = "insert into invoice values('" + label6.Text + "','" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "','" + dateTimePicker2.Value.ToString("yyyy-MM-dd") + "','" + textBox4.Text + "','" + comboBox1.SelectedItem.ToString() + "',null)";
                            cmd6.ExecuteNonQuery();
                            MessageBox.Show("INVOICE CREATED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            con.Close();

                            Form5 frm5 = new Form5(label6.Text);
                            frm5.Show();
                            this.Hide();
                        }

                    }
                }
                Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {
               // MessageBox.Show("ERROR:" + ex.Message);
                MessageBox.Show("INVOICE NUMBER ALREADY EXISTS", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Cursor.Current = Cursors.Default;
            }
            finally 
            {
                con.Close();
                comboBox1.Items.Clear();
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from PROJECT";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    comboBox1.Items.Add(dr["PROJECT"].ToString());

                }
                
                con.Close();
                Cursor.Current = Cursors.Default;                 
            }

            
            
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
               
                comboBox1.Items.Clear();               
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from PROJECT";  
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    comboBox1.Items.Add(dr["PROJECT"].ToString());

                }
                con.Close();
                Cursor.Current = Cursors.Default;
               
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                textBox2.Visible = true;
                label9.Visible = true;

            }
            else
            {
                textBox2.Visible = false;
                label9.Visible = false;
            }
        }

        private void tb_kd1(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                dateTimePicker1.Focus();
            }
        }

        private void dt_kd1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                dateTimePicker2.Focus();
            }
        }

        private void dt_kd2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox4.Focus();
            }
        }

        private void tb_kd4(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                comboBox1.Focus();
            }
        }

        private void cb_kd1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.CharacterCasing = CharacterCasing.Upper;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            textBox4.CharacterCasing = CharacterCasing.Upper;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.CharacterCasing = CharacterCasing.Upper;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                textBox1.Enabled = false;
                textBox4.Enabled = false;
                dateTimePicker1.Enabled = false;
                dateTimePicker2.Enabled = false;
                comboBox1.Enabled = false;
                textBox2.Visible = true;
                label9.Visible = true;
                textBox2.Focus();
            }
            else
            {
                textBox1.Enabled = true;
                textBox4.Enabled = true;
                dateTimePicker1.Enabled = true;
                dateTimePicker2.Enabled = true;
                comboBox1.Enabled = true;
                textBox2.Visible = false;
                label9.Visible = false;
                textBox1.Focus();
            }
        }

        private void PN_KD(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }

       

    }
}
