﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
using System.Configuration;

namespace NLC_SMS
{
    public partial class Form15 : Form
    {
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["NLC_SMS.Properties.Settings.abbConnectionString"].ConnectionString);
      
        OpenFileDialog ofd = new OpenFileDialog();
        public Form15()
        {
            InitializeComponent();
            /* , "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        , "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
         MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);   */
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd5 = con.CreateCommand();
                cmd5.CommandType = CommandType.Text;
                cmd5.CommandText = "update uhistory set ACTIONS+=', INVOICE_FILE_UPLOADED' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd5.ExecuteNonQuery();
                con.Close();
                if (textBox1.Text == "")
                {
                    MessageBox.Show("PLEASE ENTER INVOICE NUMBER", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox1.Focus();
                }
                else
                {
                    if (ofd.ShowDialog() == DialogResult.OK)
                    {
                        textBox2.Text = ofd.FileName;
                        textBox3.Text = ofd.SafeFileName;
                        textBox4.Text = label2.Text + textBox1.Text;
                    }
                   // using (SqlConnection cn = new SqlConnection(@"Data Source=DESKTOP-7RUQB76;Initial Catalog=ABB;Integrated Security=True;Pooling=False"))
                    using (SqlConnection cn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["NLC_SMS.Properties.Settings.abbConnectionString"].ConnectionString))
                    {

                        cn.Open();

                        FileStream fStream = File.OpenRead("" + textBox2.Text + "");

                        byte[] contents = new byte[fStream.Length];

                        fStream.Read(contents, 0, (int)fStream.Length);

                        fStream.Close();

                        using (SqlCommand cmd = new SqlCommand("UPDATE invoice SET PDF_FILE=(@data) where invoice_number='" + textBox4.Text + "'", cn))
                        {

                            cmd.Parameters.Add("@data", contents);

                            cmd.ExecuteNonQuery();

                            MessageBox.Show("PDF FILE UPLOADED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        }
                        cn.Close();
                        textBox1.Text = "";
                        textBox2.Text = "";
                        textBox3.Text = "";
                        textBox4.Text = "";
                    }
                }
                Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                textBox1.Focus();
                Cursor.Current = Cursors.Default;
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {

            try
            {
                this.Hide();
                Form3 frm = new Form3("ADMIN");
                frm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd6 = con.CreateCommand();
                cmd6.CommandType = CommandType.Text;
                cmd6.CommandText = "update uhistory set ACTIONS+=', INVOICE_FILE_DOWNLOADED' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd6.ExecuteNonQuery();
                con.Close();

                if (textBox1.Text == "")
                {
                    MessageBox.Show("PLEASE ENTER INVOICE NUMBER", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox1.Focus();
                }
                else
                {
                    SaveFileDialog sfd = new SaveFileDialog();
                    if (sfd.ShowDialog() == DialogResult.OK)
                    {
                        textBox2.Text = sfd.FileName;

                        textBox4.Text = label2.Text + textBox1.Text;

                        string ToSaveFileTo = "" + textBox2.Text + ".pdf";



                       // using (SqlConnection cn = new SqlConnection(@"Data Source=DESKTOP-7RUQB76;Initial Catalog=ABB;Integrated Security=True;Pooling=False"))
                       // {
                        using (SqlConnection cn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["NLC_SMS.Properties.Settings.abbConnectionString"].ConnectionString))
                        {

                            cn.Open();

                            using (SqlCommand cmd = new SqlCommand("select PDF_FILE from invoice  where invoice_number='" + textBox4.Text + "' ", cn))
                            {

                                using (SqlDataReader dr = cmd.ExecuteReader(System.Data.CommandBehavior.Default))
                                {

                                    if (dr.Read())
                                    {



                                        byte[] fileData = (byte[])dr.GetValue(0);

                                        using (System.IO.FileStream fs = new System.IO.FileStream(ToSaveFileTo, System.IO.FileMode.Create, System.IO.FileAccess.ReadWrite))
                                        {

                                            using (System.IO.BinaryWriter bw = new System.IO.BinaryWriter(fs))
                                            {

                                                bw.Write(fileData);

                                                bw.Close();
                                                MessageBox.Show("PDF FILE DOWNLOADED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            }

                                        }
                                    }
                                }
                            }
                            cn.Close();
                            textBox1.Text = "";
                            textBox2.Text = "";
                            textBox3.Text = "";
                            textBox4.Text = "";
                        }
                    }
                }
                Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {
               // MessageBox.Show("ERROR :" + ex.Message);
                MessageBox.Show("FILE NOT AVAILABLE", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                textBox1.Focus();
                Cursor.Current = Cursors.Default;
            }
        }

        private void Form15_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.CharacterCasing = CharacterCasing.Upper;
        }
    }
}
