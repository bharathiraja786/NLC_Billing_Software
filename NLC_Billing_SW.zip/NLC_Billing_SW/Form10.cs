﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace NLC_SMS
{
    public partial class Form10 : Form
    {
       // SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-7RUQB76;Initial Catalog=ABB;Integrated Security=True;Pooling=False");
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["NLC_SMS.Properties.Settings.abbConnectionString"].ConnectionString);
      
        public Form10()
        {
            InitializeComponent();
            /* , "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
          , "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
           MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);   */

        }

        private void Form10_Load(object sender, EventArgs e)
        {
            //dateTimePicker1.MaxDate = DateTime.Now;
            //dateTimePicker2.MaxDate = DateTime.Now;
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM ABB WHERE SL_NO != '0.6'ORDER BY SL_NO", con);
                DataTable dt = new DataTable();

                sda.Fill(dt);
                dataGridView1.DataSource = dt;
                //dataGridView1.Columns[0].HeaderCell.Value = "SERIAL NUMBER";
                //dataGridView1.Columns[1].HeaderCell.Value = "MATERIAL CODE";
                //dataGridView1.Columns[2].HeaderCell.Value = "MATERIAL DESCRIPTION";
                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.Columns.Remove("received_qty");
                dataGridView1.Columns.Remove("used_qty");
                dataGridView1.Columns.Remove("available_stock");

                foreach (DataGridViewColumn col in dataGridView1.Columns)
                {
                    col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    col.HeaderCell.Style.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Pixel);
                }

                dataGridView1.Columns[2].Width = 430;
                //dataGridView1.Columns[6].Width = 115;

                dataGridView1.Columns[0].HeaderText = "SERIAL NUMBER";
                dataGridView1.Columns[1].HeaderText = "MATERIAL CODE";
                dataGridView1.Columns[2].HeaderText = "MATERIAL DESCRIPTION";
                
                this.dataGridView1.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                this.dataGridView1.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    


                comboBox1.Items.Clear();
                con.Open();
                SqlCommand cmd1 = new SqlCommand();
                cmd1 = con.CreateCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "select * from PROJECT WHERE  PROJECT !='ADD NEW PROJECT'";
                cmd1.ExecuteNonQuery();
                DataTable dt1 = new DataTable();
                SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
                sda1.Fill(dt1);
                foreach (DataRow dr in dt1.Rows)
                {
                    comboBox1.Items.Add(dr["PROJECT"].ToString());

                }

            }
            catch (Exception ex)
            {
               // MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }



        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;

                dataGridView1.AutoGenerateColumns = true;
                label5.Text = label1.Text + textBox1.Text;
                if (checkedListBox1.SelectedIndex == -1)
                {
                    dataGridView1.AutoGenerateColumns = false;
                    dataGridView1.Columns.Remove("received_qty");
                    dataGridView1.Columns.Remove("used_qty");
                    dataGridView1.Columns.Remove("available_stock");
                    MessageBox.Show("PLEASE SELECT FILTER OPTIONS ", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                   

                }
                else if (checkedListBox1.SelectedIndex == 0)
                {

                    if (textBox1.Text != "")
                    {

                        SqlDataAdapter sda1 = new SqlDataAdapter("SELECT INVOICE_NUMBER as [INVOICE NUMBER],INVOICE_DATE as [INVOICE DATE],RECEIVED_DATE as [RECEIVED DATE],LR_NUMBER as [LR NUMBER],PROJECT FROM invoice where invoice_number='" + label5.Text + "' ", con);
                        DataTable dt1 = new DataTable();
                        sda1.Fill(dt1);
                        dataGridView1.DataSource = dt1;
                        checkedListBox1.SelectedIndex = -1;
                        textBox1.Text = "";
                        foreach (DataGridViewColumn col in dataGridView1.Columns)
                        {
                            col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                            col.HeaderCell.Style.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Pixel);
                        }
                        dataGridView1.Columns[0].Width = 197;
                        dataGridView1.Columns[1].Width = 175;
                        dataGridView1.Columns[2].Width = 175;
                        dataGridView1.Columns[3].Width = 175;
                        dataGridView1.Columns[4].Width = 175;
                
                    }
                    else
                    {
                        MessageBox.Show("PLEASE ENTER INVOICE NUMBER", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        textBox1.Focus();
                    }

                }
                else if (checkedListBox1.SelectedIndex == 3)
                {
                    SqlDataAdapter sda1 = new SqlDataAdapter("SELECT INVOICE_NUMBER as [INVOICE NUMBER],INVOICE_DATE as [INVOICE DATE],RECEIVED_DATE as [RECEIVED DATE],LR_NUMBER as [LR NUMBER],PROJECT FROM invoice where invoice_date between '" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "' AND '" + dateTimePicker2.Value.ToString("yyyy-MM-dd") + "' ORDER BY INVOICE_DATE", con);
                    DataTable dt1 = new DataTable();
                    sda1.Fill(dt1);
                    dataGridView1.DataSource = dt1;
                    checkedListBox1.SelectedIndex = -1;
                    foreach (DataGridViewColumn col in dataGridView1.Columns)
                    {
                        col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                        col.HeaderCell.Style.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Pixel);
                    }
                    dataGridView1.Columns[0].Width = 197;
                    dataGridView1.Columns[1].Width = 175;
                    dataGridView1.Columns[2].Width = 175;
                    dataGridView1.Columns[3].Width = 175;
                    dataGridView1.Columns[4].Width = 175;
                

                }
                else if (checkedListBox1.SelectedIndex == 4)
                {

                    SqlDataAdapter sda1 = new SqlDataAdapter("SELECT INVOICE_NUMBER as [INVOICE NUMBER],INVOICE_DATE as [INVOICE DATE],RECEIVED_DATE as [RECEIVED DATE],LR_NUMBER as [LR NUMBER],PROJECT FROM invoice where received_date between '" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "' AND '" + dateTimePicker2.Value.ToString("yyyy-MM-dd") + "' ORDER BY RECEIVED_DATE", con);
                    DataTable dt1 = new DataTable();
                    sda1.Fill(dt1);
                    dataGridView1.DataSource = dt1;
                    checkedListBox1.SelectedIndex = -1;
                    foreach (DataGridViewColumn col in dataGridView1.Columns)
                    {
                        col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                        col.HeaderCell.Style.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Pixel);
                    }
                    dataGridView1.Columns[0].Width = 197;
                    dataGridView1.Columns[1].Width = 175;
                    dataGridView1.Columns[2].Width = 175;
                    dataGridView1.Columns[3].Width = 175;
                    dataGridView1.Columns[4].Width = 175;
                


                }

                else if (checkedListBox1.SelectedIndex == 1)
                {
                    if (textBox3.Text != "")
                    {
                        SqlDataAdapter sda1 = new SqlDataAdapter("SELECT INVOICE_NUMBER as [INVOICE NUMBER],INVOICE_DATE as [INVOICE DATE],RECEIVED_DATE as [RECEIVED DATE],LR_NUMBER as [LR NUMBER],PROJECT FROM invoice where lr_number='" + textBox3.Text + "' ", con);
                        DataTable dt1 = new DataTable();
                        sda1.Fill(dt1);
                        dataGridView1.DataSource = dt1;
                        checkedListBox1.SelectedIndex = -1;
                        textBox3.Text = "";
                        foreach (DataGridViewColumn col in dataGridView1.Columns)
                        {
                            col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                            col.HeaderCell.Style.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Pixel);
                        }
                        dataGridView1.Columns[0].Width = 197;
                        dataGridView1.Columns[1].Width = 175;
                        dataGridView1.Columns[2].Width = 175;
                        dataGridView1.Columns[3].Width = 175;
                        dataGridView1.Columns[4].Width = 175;
                
                    }
                    else
                    {
                        MessageBox.Show("PLEASE ENTER LR_NUMBER", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        textBox3.Focus();
                    }
                }
                else if (checkedListBox1.SelectedIndex == 2)
                {
                    if (comboBox1.SelectedIndex != -1)
                    {
                        SqlDataAdapter sda1 = new SqlDataAdapter("SELECT INVOICE_NUMBER as [INVOICE NUMBER],INVOICE_DATE as [INVOICE DATE],RECEIVED_DATE as [RECEIVED DATE],LR_NUMBER as [LR NUMBER],PROJECT FROM invoice where PROJECT='" + comboBox1.SelectedItem.ToString() + "' ", con);
                        DataTable dt1 = new DataTable();
                        sda1.Fill(dt1);
                        dataGridView1.DataSource = dt1;
                        checkedListBox1.SelectedIndex = -1;
                        comboBox1.SelectedIndex = -1;
                        foreach (DataGridViewColumn col in dataGridView1.Columns)
                        {
                            col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                            col.HeaderCell.Style.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Pixel);
                        }
                        dataGridView1.Columns[0].Width = 197;
                        dataGridView1.Columns[1].Width = 175;
                        dataGridView1.Columns[2].Width = 175;
                        dataGridView1.Columns[3].Width = 175;
                        dataGridView1.Columns[4].Width = 175;
                
                    }
                    else
                    {
                        MessageBox.Show("PLEASE SELECT PROJECT", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        comboBox1.Focus();
                    }
                }
                else
                {
                    //MessageBox.Show("PLEASE SELECT OPTIONS FROM ABOVE CHECKBOX LIST", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                Cursor.Current = Cursors.Default;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                //dataGridView1.Columns[0].Width = 150;
                //dataGridView1.Columns[1].Width = 150;
                //dataGridView1.Columns[2].Width = 150;
                //dataGridView1.Columns[3].Width = 150;
                //dataGridView1.Columns[4].Width = 150;
                //foreach (DataGridViewColumn col in dataGridView1.Columns)
                //{
                //    col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                //    col.HeaderCell.Style.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Pixel);
                //}

               // dataGridView1.AutoGenerateColumns = false;
                label5.Text = "";
                Cursor.Current = Cursors.Default;
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                Form3 frm3 = new Form3("ADMIN");
                frm3.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                if (textBox2.Text != "")
                {
                    if (checkedListBox1.SelectedIndex == -1)
                    {

                        dataGridView1.AutoGenerateColumns = true;
                        label8.Text = label8.Text + textBox2.Text;
                        SqlDataAdapter sda1 = new SqlDataAdapter("SELECT SL_NO as [SERIAL NUMBER],M_CODE as[MATERIAL CODE],MATERIAL_DESCRIPTION as [MATERIAL DESCRIPTION],UNIT," + label8.Text + " FROM abb where sl_no!='0.6' and " + label8.Text + "!='null' and " + label8.Text + "!='0' ORDER BY SL_NO ", con);
                        DataTable dt1 = new DataTable();
                        sda1.Fill(dt1);
                        dataGridView1.DataSource = dt1;
                        foreach (DataGridViewColumn col in dataGridView1.Columns)
                        {
                            col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                            col.HeaderCell.Style.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Pixel);
                        }
                        dataGridView1.Columns[2].Width = 430;
                       // dataGridView1.Columns[4].Width = 150;
                        this.dataGridView1.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                        this.dataGridView1.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                
               
                        label8.Text = "IVN_";
                    }
                    else
                    {
                        checkedListBox1.SelectedIndex = -1;
                        dataGridView1.AutoGenerateColumns = true;
                        label8.Text = label8.Text + textBox2.Text;
                        SqlDataAdapter sda1 = new SqlDataAdapter("SELECT SL_NO as [SERIAL NUMBER],M_CODE as[MATERIAL CODE],MATERIAL_DESCRIPTION as [MATERIAL DESCRIPTION],UNIT," + label8.Text + " FROM abb  where sl_no!='0.6' and " + label8.Text + "!='null' and " + label8.Text + "!='0' ORDER BY SL_NO ", con);
                        DataTable dt1 = new DataTable();
                        sda1.Fill(dt1);
                        dataGridView1.DataSource = dt1;
                        foreach (DataGridViewColumn col in dataGridView1.Columns)
                        {
                            col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                            col.HeaderCell.Style.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Pixel);
                        }
                        dataGridView1.Columns[2].Width = 430;
                       // dataGridView1.Columns[4].Width = 150;
                        this.dataGridView1.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                        this.dataGridView1.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                
                        label8.Text = "IVN_";
                    }
                }
                else
                {
                    MessageBox.Show("PLEASE ENTER INVOICE NUMBER", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox2.Focus();
                }
                Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {
               //MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
               // dataGridView1.AutoGenerateColumns = true;
               // dataGridView1.Columns.Remove("received_qty");
               // dataGridView1.Columns.Remove("used_qty");
               // dataGridView1.Columns.Remove("available_stock");
                dataGridView1.DataSource = "";
                MessageBox.Show("INVOICE NOT AVAILABLE");
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                label8.Text = "IVN_";
                Cursor.Current = Cursors.Default;
              
            }
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                checkedListBox1.SelectedIndex = -1;
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                dlte.Text = "";
                comboBox1.SelectedIndex = -1;
                dateTimePicker1.Value = DateTime.Now;
                dateTimePicker2.Value = DateTime.Now;
                textBox1.Focus();

                Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                //dataGridView1.DataSource = "";
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM ABB WHERE SL_NO != '0.6'ORDER BY SL_NO", con);
                DataTable dt = new DataTable();

                sda.Fill(dt);
                dataGridView1.DataSource = dt;
                dataGridView1.Columns[0].HeaderText = "SERIAL NUMBER";
                dataGridView1.Columns[1].HeaderText = "MATERIAL CODE";
                dataGridView1.Columns[2].HeaderText = "MATERIAL DESCRIPTION";
               

                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.Columns.Remove("RECEIVED_QTY");
                dataGridView1.Columns.Remove("USED_QTY");
                dataGridView1.Columns.Remove("AVAILABLE_STOCK");
                foreach (DataGridViewColumn col in dataGridView1.Columns)
                {
                    col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    col.HeaderCell.Style.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Pixel);
                }

                dataGridView1.Columns[2].Width = 430;

                this.dataGridView1.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                this.dataGridView1.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                
                Cursor.Current = Cursors.Default;
               
            }
            catch (Exception ex)
            {
               // MessageBox.Show("ERROR:" + ex.Message);
                Cursor.Current = Cursors.Default;
            }
            finally 
            {
                checkedListBox1.SelectedIndex = -1;
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                comboBox1.SelectedIndex = -1;
                dateTimePicker1.Value = DateTime.Now;
                dateTimePicker2.Value = DateTime.Now;
                textBox1.Focus();
                Cursor.Current = Cursors.Default;
            }
        }


        private void TB_KD(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button3.Focus();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
               
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set ACTIONS+=', INVOICE_TO_EXCEL' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
                Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                app.Visible = true;
                app.Columns.ColumnWidth = 15;

                worksheet = workbook.Sheets["Sheet1"];
                worksheet = workbook.ActiveSheet;
                worksheet.Name = "INVOICE";

                for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)
                {
                    worksheet.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;
                }

                for (int i = 0; i <= dataGridView1.Rows.Count - 1; i++)
                {
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        worksheet.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                    }
                }
                Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.CharacterCasing = CharacterCasing.Upper;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            textBox3.CharacterCasing = CharacterCasing.Upper;
        }

        private void button7_Click(object sender, EventArgs e)
        {
                try
                {
                    Cursor.Current = Cursors.WaitCursor;

                    dataGridView1.AutoGenerateColumns = true;
                    label5.Text = label1.Text + textBox1.Text;

                    if (checkedListBox1.SelectedIndex == 0)
                    {

                        if (textBox1.Text != "")
                        {
                            dataGridView1.DataSource = "";
                            SqlDataAdapter sda1 = new SqlDataAdapter("SELECT INVOICE_NUMBER,INVOICE_DATE,RECEIVED_DATE,LR_NUMBER,PROJECT FROM invoice where invoice_number='" + label5.Text + "' ", con);
                            DataTable dt1 = new DataTable();
                            sda1.Fill(dt1);
                           // dataGridView1.DataSource = dt1;
                            checkedListBox1.SelectedIndex = -1;
                            textBox1.Text = "";
                            if( MessageBox.Show("Do You Want To Delete This Invoice Details ?", "CONFORMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question)==DialogResult.Yes)
                            {
                            foreach (DataRow dr in dt1.Rows)
                            {
                                //comboBox1.Items.Add(dr["MATERIAL_DESCRIPTION"].ToString());
                                dlte.Text = dr["INVOICE_NUMBER"].ToString();
                                con.Open();
                                SqlCommand cmd1 = new SqlCommand();
                                cmd1 = con.CreateCommand();
                                cmd1.CommandType = CommandType.Text;
                                cmd1.CommandText = " delete from INVOICE where INVOICE_NUMBER='"+dlte.Text+"'";
                                cmd1.ExecuteNonQuery();
                                con.Close();
                               // MessageBox.Show("INVOICE DELETED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                con.Open();
                                SqlCommand cmd2 = new SqlCommand();
                                cmd2 = con.CreateCommand();
                                cmd2.CommandType = CommandType.Text;
                                cmd2.CommandText = " ALTER TABLE ABB DROP COLUMN " + dlte.Text.ToString() + "";
                                cmd2.ExecuteNonQuery();
                                con.Close();
                                //MessageBox.Show("INVOICE DELETED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                dlte.Text = "";
                              
                            }
                            MessageBox.Show("INVOICE DELETED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                            
                        }
                        else
                        {
                            MessageBox.Show("PLEASE ENTER INVOICE NUMBER", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            textBox1.Focus();
                        }

                    }
                    else if (checkedListBox1.SelectedIndex == 3)
                    {
                        
                        dataGridView1.DataSource="";
                        SqlDataAdapter sda1 = new SqlDataAdapter("SELECT INVOICE_NUMBER,INVOICE_DATE,RECEIVED_DATE,LR_NUMBER,PROJECT FROM invoice where invoice_date between '" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "' AND '" + dateTimePicker2.Value.ToString("yyyy-MM-dd") + "' ORDER BY INVOICE_DATE", con);
                        DataTable dt1 = new DataTable();
                        sda1.Fill(dt1);
                      //  dataGridView1.DataSource = dt1;
                        checkedListBox1.SelectedIndex = -1;
                        if (MessageBox.Show("Do You Want To Delete This Invoice Details ?", "CONFORMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            foreach (DataRow dr in dt1.Rows)
                            {
                                //comboBox1.Items.Add(dr["MATERIAL_DESCRIPTION"].ToString());
                                dlte.Text = dr["INVOICE_NUMBER"].ToString();
                                con.Open();
                                SqlCommand cmd1 = new SqlCommand();
                                cmd1 = con.CreateCommand();
                                cmd1.CommandType = CommandType.Text;
                                cmd1.CommandText = " delete from INVOICE where INVOICE_NUMBER='" + dlte.Text + "'";
                                cmd1.ExecuteNonQuery();
                                con.Close();
                                // MessageBox.Show("INVOICE DELETED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                con.Open();
                                SqlCommand cmd2 = new SqlCommand();
                                cmd2 = con.CreateCommand();
                                cmd2.CommandType = CommandType.Text;
                                cmd2.CommandText = " ALTER TABLE ABB DROP COLUMN " + dlte.Text.ToString() + "";
                                cmd2.ExecuteNonQuery();
                                con.Close();
                                //MessageBox.Show("INVOICE DELETED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                dlte.Text = "";

                            }
                            MessageBox.Show("INVOICE DELETED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }  

                    }
                    else if (checkedListBox1.SelectedIndex == 4)
                    {
                        dataGridView1.DataSource = "";
                        SqlDataAdapter sda1 = new SqlDataAdapter("SELECT INVOICE_NUMBER,INVOICE_DATE,RECEIVED_DATE,LR_NUMBER,PROJECT FROM invoice where received_date between '" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "' AND '" + dateTimePicker2.Value.ToString("yyyy-MM-dd") + "' ORDER BY RECEIVED_DATE", con);
                        DataTable dt1 = new DataTable();
                        sda1.Fill(dt1);
                      //  dataGridView1.DataSource = dt1;
                        checkedListBox1.SelectedIndex = -1;

                        if (MessageBox.Show("Do You Want To Delete This Invoice Details ?", "CONFORMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            foreach (DataRow dr in dt1.Rows)
                            {
                                //comboBox1.Items.Add(dr["MATERIAL_DESCRIPTION"].ToString());
                                dlte.Text = dr["INVOICE_NUMBER"].ToString();
                                con.Open();
                                SqlCommand cmd1 = new SqlCommand();
                                cmd1 = con.CreateCommand();
                                cmd1.CommandType = CommandType.Text;
                                cmd1.CommandText = " delete from INVOICE where INVOICE_NUMBER='" + dlte.Text + "'";
                                cmd1.ExecuteNonQuery();
                                con.Close();
                                // MessageBox.Show("INVOICE DELETED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                con.Open();
                                SqlCommand cmd2 = new SqlCommand();
                                cmd2 = con.CreateCommand();
                                cmd2.CommandType = CommandType.Text;
                                cmd2.CommandText = " ALTER TABLE ABB DROP COLUMN " + dlte.Text.ToString() + "";
                                cmd2.ExecuteNonQuery();
                                con.Close();
                                // MessageBox.Show("INVOICE DELETED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                dlte.Text = "";

                            }
                            MessageBox.Show("INVOICE DELETED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }  

                    }

                    else if (checkedListBox1.SelectedIndex == 1)
                    {
                        if (textBox3.Text != "")
                        {
                            dataGridView1.DataSource = "";
                            SqlDataAdapter sda1 = new SqlDataAdapter("SELECT INVOICE_NUMBER,INVOICE_DATE,RECEIVED_DATE,LR_NUMBER,PROJECT FROM invoice where lr_number='" + textBox3.Text + "' ", con);
                            DataTable dt1 = new DataTable();
                            sda1.Fill(dt1);
                           // dataGridView1.DataSource = dt1;
                            checkedListBox1.SelectedIndex = -1;
                            textBox3.Text = "";
                            if (MessageBox.Show("Do You Want To Delete This Invoice Details ?", "CONFORMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {
                                foreach (DataRow dr in dt1.Rows)
                                {
                                    //comboBox1.Items.Add(dr["MATERIAL_DESCRIPTION"].ToString());
                                    dlte.Text = dr["INVOICE_NUMBER"].ToString();
                                    con.Open();
                                    SqlCommand cmd1 = new SqlCommand();
                                    cmd1 = con.CreateCommand();
                                    cmd1.CommandType = CommandType.Text;
                                    cmd1.CommandText = " delete from INVOICE where INVOICE_NUMBER='" + dlte.Text + "'";
                                    cmd1.ExecuteNonQuery();
                                    con.Close();
                                    // MessageBox.Show("INVOICE DELETED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    con.Open();
                                    SqlCommand cmd2 = new SqlCommand();
                                    cmd2 = con.CreateCommand();
                                    cmd2.CommandType = CommandType.Text;
                                    cmd2.CommandText = " ALTER TABLE ABB DROP COLUMN " + dlte.Text.ToString() + "";
                                    cmd2.ExecuteNonQuery();
                                    con.Close();
                                    //MessageBox.Show("INVOICE DELETED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    dlte.Text = "";

                                }
                                MessageBox.Show("INVOICE DELETED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                        else
                        {
                            MessageBox.Show("PLEASE ENTER LR_NUMBER", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            textBox3.Focus();
                        }
                    }
                    else if (checkedListBox1.SelectedIndex == 2)
                    {
                        if (comboBox1.SelectedIndex != -1)
                        {
                            dataGridView1.DataSource = "";
                            SqlDataAdapter sda1 = new SqlDataAdapter("SELECT INVOICE_NUMBER,INVOICE_DATE,RECEIVED_DATE,LR_NUMBER,PROJECT FROM invoice where PROJECT='" + comboBox1.SelectedItem.ToString() + "' ", con);
                            DataTable dt1 = new DataTable();
                            sda1.Fill(dt1);
                         //   dataGridView1.DataSource = dt1;
                            checkedListBox1.SelectedIndex = -1;
                            comboBox1.SelectedIndex = -1;
                            if (MessageBox.Show("Do You Want To Delete This Invoice Details ?", "CONFORMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {
                                foreach (DataRow dr in dt1.Rows)
                                {
                                    //comboBox1.Items.Add(dr["MATERIAL_DESCRIPTION"].ToString());
                                    dlte.Text = dr["INVOICE_NUMBER"].ToString();
                                    con.Open();
                                    SqlCommand cmd1 = new SqlCommand();
                                    cmd1 = con.CreateCommand();
                                    cmd1.CommandType = CommandType.Text;
                                    cmd1.CommandText = " delete from INVOICE where INVOICE_NUMBER='" + dlte.Text + "'";
                                    cmd1.ExecuteNonQuery();
                                    con.Close();
                                    // MessageBox.Show("INVOICE DELETED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    con.Open();
                                    SqlCommand cmd2 = new SqlCommand();
                                    cmd2 = con.CreateCommand();
                                    cmd2.CommandType = CommandType.Text;
                                    cmd2.CommandText = " ALTER TABLE ABB DROP COLUMN " + dlte.Text.ToString() + "";
                                    cmd2.ExecuteNonQuery();
                                    con.Close();
                                    dlte.Text = "";

                                }
                                MessageBox.Show("INVOICE DELETED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }  
                        }
                        else
                        {
                            MessageBox.Show("PLEASE SELECT PROJECT", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            comboBox1.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("PLEASE SELECT OPTIONS FROM ABOVE CHECKBOX LIST", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    Cursor.Current = Cursors.Default;

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Cursor.Current = Cursors.Default;
                }
                finally
                {
                    dataGridView1.DataSource = "";
                    label5.Text = "";
                    dlte.Text = "";
                    Cursor.Current = Cursors.Default;
                }           
        }
    }
}