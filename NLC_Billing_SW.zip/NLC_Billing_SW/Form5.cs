﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data.Sql;
using System.Configuration;


namespace NLC_SMS
{
    public partial class Form5 : Form
    {
       // SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-7RUQB76;Initial Catalog=ABB;Integrated Security=True;Pooling=False");
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["NLC_SMS.Properties.Settings.abbConnectionString"].ConnectionString);
      
        public Form5(string value)
        {
            InitializeComponent();
            label4.Text = value;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
            this.Hide();
            Form3 frm3 = new Form3("ADMIN");
            frm3.Show();
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
            finally
            {
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
            this.Hide();
            Form1 frm1 = new Form1();
            frm1.Show();
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
            finally
            {
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
           /* try
            {
                this.Hide();
                Form3 frm3 = new Form3();
                frm3.Show();
            }            
            catch (Exception EX)
            {
                MessageBox.Show("ERROR: " + EX.Message);
            }
            finally
            {
            }*/
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;               
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT M_CODE,MATERIAL_DESCRIPTION FROM ABB WHERE SL_NO!='0.1' AND SL_NO!='0.2' AND SL_NO!='0.3' AND SL_NO!='0.4' AND SL_NO!='0.5' ORDER BY SL_NO";
            cmd.ExecuteNonQuery();/*CHANGE COLUMN NAME SL_NO TO M_CODE*/
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                comboBox1.Items.Add(dr["MATERIAL_DESCRIPTION"].ToString());
                comboBox2.Items.Add(dr["M_CODE"].ToString());//SL_NO TO M_CODE
            }
            con.Close();
            Cursor.Current = Cursors.Default;
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                if (comboBox1.SelectedIndex == -1 | comboBox1.Text=="")
                {
                    MessageBox.Show("PLEASE SELECT MATERIAL_DESCRIPTION","WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    comboBox1.Focus();
                }
                else if (comboBox2.SelectedIndex == -1 | comboBox2.Text=="")
                {
                    MessageBox.Show("PLEASE SELECT MATERIAL_CODE", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    comboBox2.Focus();
                }
                else if (textBox1.Text == "")
                {
                    MessageBox.Show("PLEASE ENTER MATERIAL_QUANTITY", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox1.Focus();
                }
                else
                {
                    double a, b, c;
                    double.TryParse(textBox3.Text, out a);
                    double.TryParse(textBox1.Text, out b);

                    if (a == 0 | a == null)
                    {
                        con.Open();
                        SqlCommand cmd1 = con.CreateCommand();
                        cmd1.CommandType = CommandType.Text;
                        cmd1.CommandText = "update ABB set " + label4.Text + " = '" + textBox1.Text + "' where MATERIAL_DESCRIPTION ='" + comboBox1.SelectedItem + "' ";
                        cmd1.ExecuteNonQuery();

                        SqlCommand cmd2 = con.CreateCommand();
                        cmd2.CommandType = CommandType.Text;
                        cmd2.CommandText = "update ABB set RECEIVED_QTY +='" + textBox1.Text + "' where MATERIAL_DESCRIPTION ='" + comboBox1.SelectedItem + "' ";
                        cmd2.ExecuteNonQuery();

                        SqlCommand cmd3 = con.CreateCommand();
                        cmd3.CommandType = CommandType.Text;
                        cmd3.CommandText = "update ABB set AVAILABLE_STOCK +='" + textBox1.Text + "' where MATERIAL_DESCRIPTION ='" + comboBox1.SelectedItem + "' ";
                        cmd3.ExecuteNonQuery();

                        con.Close();
                        MessageBox.Show("UPDATED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        
                    }
                    else if (a > b)
                    {

                        c = a - b;
                        textBox3.Text = Convert.ToString(c);

                        
                        con.Open();
                        SqlCommand cmd1 = con.CreateCommand();
                        cmd1.CommandType = CommandType.Text;
                        cmd1.CommandText = "update ABB set " + label4.Text + " ='" + textBox1.Text + "'  where MATERIAL_DESCRIPTION ='" + comboBox1.SelectedItem + "' ";
                        cmd1.ExecuteNonQuery();

                        SqlCommand cmd2 = con.CreateCommand();
                        cmd2.CommandType = CommandType.Text;
                        cmd2.CommandText = "update ABB set RECEIVED_QTY =RECEIVED_QTY-'" + textBox3.Text + "' where MATERIAL_DESCRIPTION ='" + comboBox1.SelectedItem + "' ";
                        cmd2.ExecuteNonQuery();

                        SqlCommand cmd3 = con.CreateCommand();
                        cmd3.CommandType = CommandType.Text;
                        cmd3.CommandText = "update ABB set AVAILABLE_STOCK =AVAILABLE_STOCK-'" + textBox3.Text + "' where MATERIAL_DESCRIPTION ='" + comboBox1.SelectedItem + "' ";
                        cmd3.ExecuteNonQuery();

                        con.Close();
                        MessageBox.Show("UPDATED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        
                    }

                    else if (a < b)
                    {
                        c = b - a;

                        textBox3.Text = Convert.ToString(c);

                        con.Open();
                        SqlCommand cmd1 = con.CreateCommand();
                        cmd1.CommandType = CommandType.Text;
                        cmd1.CommandText = "update ABB set " + label4.Text + " = '" + textBox1.Text + "' where MATERIAL_DESCRIPTION ='" + comboBox1.SelectedItem + "' ";
                        cmd1.ExecuteNonQuery();

                        SqlCommand cmd2 = con.CreateCommand();
                        cmd2.CommandType = CommandType.Text;
                        cmd2.CommandText = "update ABB set RECEIVED_QTY =RECEIVED_QTY+'" + textBox3.Text + "' where MATERIAL_DESCRIPTION ='" + comboBox1.SelectedItem + "' ";
                        cmd2.ExecuteNonQuery();

                        SqlCommand cmd3 = con.CreateCommand();
                        cmd3.CommandType = CommandType.Text;
                        cmd3.CommandText = "update ABB set AVAILABLE_STOCK =AVAILABLE_STOCK+'" + textBox3.Text + "' where MATERIAL_DESCRIPTION ='" + comboBox1.SelectedItem + "' ";
                        cmd3.ExecuteNonQuery();

                        con.Close();
                        MessageBox.Show("UPDATED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                        MessageBox.Show("UPDATED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Cursor.Current = Cursors.Default;
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                textBox3.Text = textBox1.Text;
                comboBox1.Focus();
                Cursor.Current = Cursors.Default;
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
               
            if (comboBox1.SelectedIndex != 0)
            {
                comboBox2.Items.Clear();
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select M_CODE from ABB where MATERIAL_DESCRIPTION='" + comboBox1.Text + "' ";//SL_NO TO M_CODE
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);

                foreach (DataRow dr in dt.Rows)
                {
                    comboBox2.Items.Add(dr["M_CODE"].ToString());//SL_NO TO M_CODE
                    comboBox2.SelectedIndex = 0;
                }
                con.Close();


                con.Open();
                SqlCommand cmd1 = new SqlCommand();
                cmd1 = con.CreateCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "select " + label4.Text + " from ABB where MATERIAL_DESCRIPTION='" + comboBox1.Text + "' ";
                cmd1.ExecuteNonQuery();
                DataTable dt1 = new DataTable();
                SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
                sda1.Fill(dt1);
                foreach (DataRow dr1 in dt1.Rows)
                {
                    textBox3.Text = dr1["" + label4.Text + ""].ToString();
                }
               // MessageBox.Show(textBox3.Text);
                con.Close();
                Cursor.Current = Cursors.Default;
               
            }
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }
        

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
               
            if (comboBox2.SelectedIndex != 0)
            {
                comboBox1.Items.Clear();
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select MATERIAL_DESCRIPTION from ABB where M_CODE='" + comboBox2.Text + "' ";// SL_NO TO M_CODE
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);

                foreach (DataRow dr in dt.Rows)
                {

                    comboBox1.Items.Add(dr["MATERIAL_DESCRIPTION"].ToString());
                    comboBox1.SelectedIndex = 0;
                }
                con.Close();


                con.Open();
                SqlCommand cmd1 = new SqlCommand();
                cmd1 = con.CreateCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "select " + label4.Text + " from ABB where M_CODE='" + comboBox2.Text + "' ";// SL_NO TO M_CODE
                cmd1.ExecuteNonQuery();
                DataTable dt1 = new DataTable();
                SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
                sda1.Fill(dt1);
                foreach (DataRow dr1 in dt1.Rows)
                {
                    textBox3.Text = dr1["" + label4.Text + ""].ToString();
                }
               // MessageBox.Show(textBox3.Text);
                con.Close();
            }
            Cursor.Current = Cursors.Default;
               
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
           


            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                comboBox1.Items.Clear();
                comboBox2.Items.Clear();
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT M_CODE,MATERIAL_DESCRIPTION FROM ABB WHERE SL_NO!='0.1' AND SL_NO!='0.2' AND SL_NO!='0.3' AND SL_NO!='0.4' AND SL_NO!='0.5' ORDER BY SL_NO";
                cmd.ExecuteNonQuery();/*CHANGE COLUMN NAME SL_NO TO M_CODE*/
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    comboBox1.Items.Add(dr["MATERIAL_DESCRIPTION"].ToString());
                    comboBox2.Items.Add(dr["M_CODE"].ToString());//SL_NO TO M_CODE
                }
                con.Close();
                Cursor.Current = Cursors.Default;
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();

                textBox1.Text = "";
                comboBox1.SelectedIndex = 0;
                comboBox2.SelectedIndex = 0;
                comboBox1.Focus();
                Cursor.Current = Cursors.Default;
            }
        }

        private void cb_kd1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                comboBox2.Focus();
            }
        }

        private void cb_kd2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox1.Focus();
            }

        }

        private void tb_kd1(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox1.Text, "[^0-9]"))
            {
                MessageBox.Show("PLEASE ENTR ONLY NUMBERS", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Text = textBox1.Text.Remove(textBox1.Text.Length - 1);

            }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
            finally
            {
            }
        }
    }
}

