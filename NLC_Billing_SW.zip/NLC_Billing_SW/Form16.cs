﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace NLC_SMS
{
    public partial class Form16 : Form
    {
       // SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-7RUQB76;Initial Catalog=ABB;Integrated Security=True;Pooling=False");
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["NLC_SMS.Properties.Settings.abbConnectionString"].ConnectionString);
                    
      
        public Form16()
        {
            InitializeComponent();
            /* , "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        , "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
         MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);   */        
        }

        private void Form16_Load(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                SqlDataAdapter sda = new SqlDataAdapter("select USER_ID as [USER ID],LOGIN_DT as [LOGIN DATE TIME],LOGOUT_DT as[LOGOUT DATE TIME],ACTIONS from UHISTORY ORDER BY LOGIN_DT DESC", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
                foreach (DataGridViewColumn col in dataGridView1.Columns)
                {
                    col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    col.HeaderCell.Style.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Pixel);
                }
                dataGridView1.Columns[0].Width = 200;
                dataGridView1.Columns[1].Width = 150;
                dataGridView1.Columns[2].Width = 150;
                dataGridView1.Columns[3].Width = 440;



                comboBox1.Items.Clear();
                con.Open();
                SqlCommand cmd1 = new SqlCommand();
                cmd1 = con.CreateCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "select USER_ID from LOGIN WHERE  USER_ID !='ADVANCED' and USER_ID !='CONNECTIONSTRING'";
                cmd1.ExecuteNonQuery();
                DataTable dt1 = new DataTable();
                SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
                sda1.Fill(dt1);
                foreach (DataRow dr in dt1.Rows)
                {
                    comboBox1.Items.Add(dr["USER_ID"].ToString());

                }
               
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;

            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                Form3 frm3 = new Form3("ADMIN");
                frm3.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
               
                if (checkedListBox1.SelectedIndex == 0)
                {
                    if (comboBox1.SelectedIndex != -1)
                    {
                        SqlDataAdapter sda = new SqlDataAdapter("select USER_ID as [USER ID],LOGIN_DT as [LOGIN DATE TIME],LOGOUT_DT as[LOGOUT DATE TIME],ACTIONS from UHISTORY WHERE USER_ID='" + comboBox1.SelectedItem.ToString() + "' ORDER BY LOGIN_DT DESC ", con);
                    DataTable dt = new DataTable();
                   
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;
                    checkedListBox1.SelectedIndex = -1;
                    dateTimePicker1.Value = DateTime.Now;
                    dateTimePicker2.Value = DateTime.Now;
                    comboBox1.SelectedIndex = -1;
                    }
                    else
                        MessageBox.Show("PLEASE SELECT USER_ID", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (checkedListBox1.SelectedIndex == 2)
                {
                    if (comboBox1.SelectedIndex != -1)
                    {

                        SqlDataAdapter sda = new SqlDataAdapter("select USER_ID as [USER ID],LOGIN_DT as [LOGIN DATE TIME],LOGOUT_DT as[LOGOUT DATE TIME],ACTIONS from UHISTORY WHERE (LOGIN_DT BETWEEN '" + dateTimePicker1.Value.ToString("yyyy-MM-dd 00:00:00") + "' and '" + dateTimePicker2.Value.ToString("yyyy-MM-dd 23:59:59") + "') AND USER_ID='" + comboBox1.SelectedItem.ToString() + "' order by LOGIN_DT DESC ", con);
                        DataTable dt = new DataTable();                       
                        sda.Fill(dt);
                        dataGridView1.DataSource = dt;
                        checkedListBox1.SelectedIndex = -1;
                        dateTimePicker1.Value = DateTime.Now;
                        dateTimePicker2.Value = DateTime.Now;
                        comboBox1.SelectedIndex = -1;
                    }
                    else
                    {
                        MessageBox.Show("PLEASE SELECT USER_ID", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        comboBox1.Focus();
                    }
                }
                else if (checkedListBox1.SelectedIndex == 1)
                {

                    SqlDataAdapter sda = new SqlDataAdapter("select USER_ID as [USER ID],LOGIN_DT as [LOGIN DATE TIME],LOGOUT_DT as[LOGOUT DATE TIME],ACTIONS from UHISTORY WHERE LOGIN_DT BETWEEN '" + dateTimePicker1.Value.ToString("yyyy-MM-dd 00:00:00") + "' and '" + dateTimePicker2.Value.ToString("yyyy-MM-dd 23:59:59") + "'order by LOGIN_DT DESC", con);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        dataGridView1.DataSource = dt;
                        checkedListBox1.SelectedIndex = -1;
                        dateTimePicker1.Value = DateTime.Now;
                        dateTimePicker2.Value = DateTime.Now;
                        comboBox1.SelectedIndex = -1;
                  

                }
                else
                {
                    MessageBox.Show("PLEASE SELECT ANY ONE FILTER OPTION", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    checkedListBox1.SelectedIndex = -1;
                    dateTimePicker1.Value = DateTime.Now;
                    dateTimePicker2.Value = DateTime.Now;
                    comboBox1.SelectedIndex = -1;
                }
                Cursor.Current = Cursors.Default;
               
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                checkedListBox1.SelectedIndex = -1;
                dateTimePicker1.Value = DateTime.Now;
                dateTimePicker2.Value = DateTime.Now;
                comboBox1.SelectedIndex = -1;
                Cursor.Current = Cursors.Default;
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd5 = con.CreateCommand();
                cmd5.CommandType = CommandType.Text;
                cmd5.CommandText = "update uhistory set ACTIONS+=', LOGIN_HISTORY_TO_EXCEL' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd5.ExecuteNonQuery();
                con.Close();

               
                Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                app.Visible = true;
                app.Columns.ColumnWidth = 15;

                worksheet = workbook.Sheets["Sheet1"];
                worksheet = workbook.ActiveSheet;
                worksheet.Name = "LOGIN HISTORY";

                for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)
                {
                    worksheet.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;
                }

                for (int i = 0; i <= dataGridView1.Rows.Count - 1; i++)
                {
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        worksheet.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                    }
                }
                Cursor.Current = Cursors.Default;
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

      

       
     
    }
}
