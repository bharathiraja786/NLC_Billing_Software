﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Threading;

namespace NLC_SMS
{
    public partial class Form1 : Form
    {
       // SqlConnection con = new SqlConnection(@"Data Source=BHARATHI;Initial Catalog=ABB;Integrated Security=True"); 

        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["NLC_SMS.Properties.Settings.abbConnectionString"].ConnectionString);
        public Form1()
        {
           Thread t = new Thread(new ThreadStart(StartForm));
            t.Start();
            Thread.Sleep(5000);
            InitializeComponent();
            t.Abort();
           // InitializeComponent();
        }
        public void StartForm()
        {
            Application.Run(new splash());
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

  

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                 if (textBox1.Text == "")
                {
                    MessageBox.Show("PLEASE ENTER USER_ID", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox1.Focus();
                }
                 else if (textBox2.Text == "")
                 {
                     MessageBox.Show("PLEASE ENTER PASSWORD", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                     textBox2.Focus();
                 }
                 else
                 {
                     SqlDataAdapter sda = new SqlDataAdapter("select count(*) from login where user_id='" + textBox1.Text + "' and pwd='" + textBox2.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS", con);
                     DataTable dt = new DataTable();
                     sda.Fill(dt);

                     //dataGridView1.DataSource=dt;

                     if (dt.Rows[0][0].ToString() == "1")
                     {
                         
                         if (textBox1.Text == "CONNECTIONSTRING")
                         {
                             this.Hide();
                             constring frm = new constring();
                             frm.Show();
                         }
                         else if (textBox1.Text == "ADVANCED")
                         {
                             this.Hide();
                             ADMIN frm = new ADMIN();
                             frm.Show();
                         }
                         else
                         {

                             con.Open();
                             SqlCommand cmd = con.CreateCommand();
                             cmd.CommandType = CommandType.Text;
                             cmd.CommandText = "insert into uhistory (USER_ID,LOGIN_DT,ACTIONS) values('" + textBox1.Text + "','" + dateTimePicker1.Value.ToString("yyyy-MM-dd HH:mm:ss") + "','LOGGED_IN')";// set user_id = role;
                             cmd.ExecuteNonQuery();
                             con.Close();
                             this.Hide();
                             Form3 frm3 = new Form3(textBox1.Text);//set textbox1.text= label5.text;
                             frm3.Show();
                         }

                     }
                     else
                     {
                         MessageBox.Show("PLEASE CHECK LOGIN DETAILS", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                         textBox2.Text = "";
                         con.Close();
                     }
                 }
                 Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
              
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            } 
            

            
        }

        private void TEXTBOX1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox2.Focus();
            }
        }

        private void tb2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }

        }
        
        private void b1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
           
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
        }

        private void flkd(object sender, KeyEventArgs e)
        {
           
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.CharacterCasing = CharacterCasing.Upper;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (checkBox1.Checked==true)
                {
                    textBox2.UseSystemPasswordChar = true;
                }
                else
                {
                    textBox2.UseSystemPasswordChar = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
            }

        }

        

    }
}
