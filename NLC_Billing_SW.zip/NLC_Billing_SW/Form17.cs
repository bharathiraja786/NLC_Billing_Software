﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace NLC_SMS
{
    public partial class Form17 : Form
    {
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["NLC_SMS.Properties.Settings.abbConnectionString"].ConnectionString);
      
        public Form17(string value)
        {
            InitializeComponent();
            label15.Text = value;
            /* , "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        , "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
         MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);   */
        }

        private void Form17_Load(object sender, EventArgs e)
        {
            if(label15.Text!="ADMIN")
            {
                button3.Enabled = false;
                button5.Enabled = false;
            }
            
            try
            {



                Cursor.Current = Cursors.WaitCursor;

                SqlDataAdapter sda = new SqlDataAdapter("SELECT DATE,MACHINE_ID as [MACHINE ID],ELEC_STOP as [ELECTRICAL STOPPAGE],MEC_STOP as [MECHANICAL STOPPAGE],SYS_STOP as [SYSTEM STOPPAGE],WORKING_Hrs as [EFFECTIVE WORKING HOURS],AVAILABILITY FROM MACHINES_WD ORDER BY DATE", con);
                DataTable dt = new DataTable();

                sda.Fill(dt);
                dataGridView1.DataSource = dt;//
               
                foreach (DataGridViewColumn col in dataGridView1.Columns)
                {
                    col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    col.HeaderCell.Style.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Pixel);
                }
                //this.dataGridView1.Columns[0].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                //this.dataGridView1.Columns[2].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                //this.dataGridView1.Columns[6].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
               
               
                dataGridView1.Columns[0].Width = 100;
                dataGridView1.Columns[1].Width = 160;
                dataGridView1.Columns[2].Width = 155;
                dataGridView1.Columns[3].Width = 160;
                dataGridView1.Columns[4].Width = 128;
                dataGridView1.Columns[5].Width = 185;
                dataGridView1.Columns[6].Width = 110;
                this.dataGridView1.Columns["DATE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; 
                this.dataGridView1.Columns["MACHINE ID"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                this.dataGridView1.Columns["SYSTEM STOPPAGE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                this.dataGridView1.Columns["ELECTRICAL STOPPAGE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                this.dataGridView1.Columns["MECHANICAL STOPPAGE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; 
                this.dataGridView1.Columns["EFFECTIVE WORKING HOURS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                this.dataGridView1.Columns["AVAILABILITY"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;     

                con.Open();
                SqlCommand cmd1 = new SqlCommand();
                cmd1 = con.CreateCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "select * from MACHINES";
                cmd1.ExecuteNonQuery();
                DataTable dt1 = new DataTable();
                SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
                sda1.Fill(dt1);
                foreach (DataRow dr in dt1.Rows)
                {
                    comboBox1.Items.Add(dr["MACHINE_ID"].ToString());
                    comboBox2.Items.Add(dr["MACHINE_ID"].ToString());
                }
                comboBox2.Items[0]="";
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.SelectedIndex == 0)
                {
                    textBox2.Visible = true;
                    label3.Visible = true;
                    label6.Visible = true;
                }
                else
                {
                    textBox2.Visible = false;
                    label3.Visible = false;
                    label6.Visible = false;
                }


            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            finally
            {
             
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (checkedListBox2.SelectedIndex == 2)
                {

                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "insert into MACHINES (MACHINE_ID) values('" + textBox2.Text + "')";
                    cmd.ExecuteNonQuery();
                    //  MessageBox.Show("INSERTED machine_id SUCCESSFULLY");
                    MessageBox.Show("MACHINE NAME ADDED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();
                }
                else if (checkedListBox2.SelectedIndex == 0)
                {

                    Cursor.Current = Cursors.WaitCursor;

                    string b, c, d, g, f;
                    b = dateTimePicker4.Value.ToString("HH:mm");
                    c = dateTimePicker5.Value.ToString("HH:mm");
                    d = dateTimePicker6.Value.ToString("HH:mm");
                    f = dateTimePicker7.Value.ToString("HH:mm");
                    g = dateTimePicker8.Value.ToString("HH:mm");


                    //  textBox1.Text = mid



                    if (comboBox1.SelectedIndex == -1)
                    {
                        MessageBox.Show("PLEASE SELECT MACHINE_ID", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        comboBox1.Focus();
                    }
                    //else if (b == "00:00")
                    //{
                    //    MessageBox.Show("PLEASE ENTER WORKING_HOURS", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //    dateTimePicker4.Focus();
                    //}
                    //else if (c == "00:00")
                    //{
                    //    MessageBox.Show("PLEASE ENTER ELECTRICAL STOPPAGE", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //    dateTimePicker5.Focus();
                    //}
                    //else if (d == "00:00")
                    //{
                    //    MessageBox.Show("PLEASE ENTER MECHANICAL STOPPAGE", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //    dateTimePicker6.Focus();
                    //}
                    //else if (f == "00:00")
                    //{
                    //    MessageBox.Show("PLEASE ENTER SYSTEM STOPPAGE", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //    dateTimePicker7.Focus();
                    //}
                    //else if (g == "00:00")
                    //{
                    //    MessageBox.Show("PLEASE ENTER AVAILABILITY", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //    dateTimePicker8.Focus();
                    //}
                    else if (comboBox1.SelectedIndex == 0)
                    {
                        if (textBox2.Text == "")
                        {
                            MessageBox.Show("PLEASE ENTER NEW_MACHINE NAME", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            textBox2.Focus();
                        }
                        else
                        {
                            con.Open();
                            SqlCommand cmd2 = con.CreateCommand();
                            cmd2.CommandType = CommandType.Text;
                            cmd2.CommandText = "select machine_id from machines where machine_id='" + textBox2.Text + "'";
                            cmd2.ExecuteNonQuery();
                            string mid = Convert.ToString(cmd2.ExecuteScalar());
                            con.Close();

                            if (mid == textBox2.Text)
                            {
                                MessageBox.Show("ENTERED MACHINE_NAME ALREADY EXISTS", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                textBox2.Focus();
                            }
                            else
                            {
                                con.Open();
                                SqlCommand cmd3 = con.CreateCommand();
                                cmd3.CommandType = CommandType.Text;
                                cmd3.CommandText = "insert into MACHINES_WD (MACHINE_ID,WORKING_HRS,DATE,ELEC_STOP,MEC_STOP,SYS_STOP,AVAILABILITY) values('" + textBox2.Text + "','" + dateTimePicker4.Value.ToString("HH:mm") + "','" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "','" + dateTimePicker5.Value.ToString("HH:mm") + "','" + dateTimePicker6.Value.ToString("HH:mm") + "','" + dateTimePicker7.Value.ToString("HH:mm") + "','" + dateTimePicker8.Value.ToString("HH:mm") + "')";
                                cmd3.ExecuteNonQuery();


                                SqlCommand cmd = con.CreateCommand();
                                cmd.CommandType = CommandType.Text;
                                cmd.CommandText = "insert into MACHINES (MACHINE_ID) values('" + textBox2.Text + "')";
                                cmd.ExecuteNonQuery();
                                //  MessageBox.Show("INSERTED machine_id SUCCESSFULLY");
                                MessageBox.Show("INSERTED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                con.Close();
                                //  }
                            }

                        }
                    }
                    else 
                    {
                        con.Open();
                        SqlCommand cmd3 = con.CreateCommand();
                        cmd3.CommandType = CommandType.Text;
                        cmd3.CommandText = "insert into MACHINES_WD (MACHINE_ID,WORKING_HRS,DATE,ELEC_STOP,MEC_STOP,SYS_STOP,AVAILABILITY) values('" + comboBox1.SelectedItem.ToString() + "','" + dateTimePicker4.Value.ToString("HH:mm") + "','" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "','" + dateTimePicker5.Value.ToString("HH:mm") + "','" + dateTimePicker6.Value.ToString("HH:mm") + "','" + dateTimePicker7.Value.ToString("HH:mm") + "','" + dateTimePicker8.Value.ToString("HH:mm") + "')";
                        cmd3.ExecuteNonQuery();
                        MessageBox.Show("INSERTED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        con.Close();
                    }

                    con.Open();
                    comboBox1.Items.Clear();
                    SqlCommand cmd1 = new SqlCommand();
                    cmd1 = con.CreateCommand();
                    cmd1.CommandType = CommandType.Text;
                    cmd1.CommandText = "select * from MACHINES";
                    cmd1.ExecuteNonQuery();
                    DataTable dt1 = new DataTable();
                    SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
                    sda1.Fill(dt1);
                    foreach (DataRow dr in dt1.Rows)
                    {
                        comboBox1.Items.Add(dr["MACHINE_ID"].ToString());
                    }
                    Cursor.Current = Cursors.Default;
                }
                else if (checkedListBox2.SelectedIndex == 1)
                {
                    Cursor.Current = Cursors.WaitCursor;

                    string b, c, d, g, f;
                    b = dateTimePicker4.Value.ToString("HH:mm");
                    c = dateTimePicker5.Value.ToString("HH:mm");
                    d = dateTimePicker6.Value.ToString("HH:mm");
                    f = dateTimePicker7.Value.ToString("HH:mm");
                    g = dateTimePicker8.Value.ToString("HH:mm");


                    //  textBox1.Text = mid



                    if (comboBox1.SelectedIndex == -1)
                    {
                        MessageBox.Show("PLEASE SELECT MACHINE_ID", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        comboBox1.Focus();
                    }
                    //else if (b == "00:00")
                    //{
                    //    MessageBox.Show("PLEASE ENTER WORKING_HOURS", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //    dateTimePicker4.Focus();
                    //}
                    //else if (c == "00:00")
                    //{
                    //    MessageBox.Show("PLEASE ENTER ELECTRICAL STOPPAGE", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //    dateTimePicker5.Focus();
                    //}
                    //else if (d == "00:00")
                    //{
                    //    MessageBox.Show("PLEASE ENTER MECHANICAL STOPPAGE", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //    dateTimePicker6.Focus();
                    //}
                    //else if (f == "00:00")
                    //{
                    //    MessageBox.Show("PLEASE ENTER SYSTEM STOPPAGE", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //    dateTimePicker7.Focus();
                    //}
                    //else if (g == "00:00")
                    //{
                    //    MessageBox.Show("PLEASE ENTER AVAILABILITY", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //    dateTimePicker8.Focus();
                    //}
                    else if (comboBox1.SelectedIndex == 0)
                    {
                        MessageBox.Show("PLEASE SELECT MACHINE_ID", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        comboBox1.Focus();

                    }
                    else
                    {
                        if (MessageBox.Show("ARE YOU SURE WANT TO UPDATE MACHINE_WD ", "CONFORMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            con.Open();
                            SqlCommand cmd3 = con.CreateCommand();
                            cmd3.CommandType = CommandType.Text;
                            cmd3.CommandText = "UPDATE MACHINES_WD set WORKING_HRS='" + dateTimePicker4.Value.ToString("HH:mm") + "',ELEC_STOP='" + dateTimePicker5.Value.ToString("HH:mm") + "',MEC_STOP='" + dateTimePicker6.Value.ToString("HH:mm") + "',SYS_STOP='" + dateTimePicker7.Value.ToString("HH:mm") + "',AVAILABILITY='" + dateTimePicker8.Value.ToString("HH:mm") + "' where MACHINE_ID='" + comboBox1.SelectedItem.ToString() + "' and DATE='" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "' ";
                            cmd3.ExecuteNonQuery();
                            MessageBox.Show("UPDATED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            con.Close();
                        }
                    }


                    Cursor.Current = Cursors.Default;
                }
                else
                {
                    MessageBox.Show("PLEASE SELECT ANY ONE OPTION","WARNING",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    checkedListBox1.Focus();
                }

            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;

            }
            finally
            {
                con.Close();
                try
                {
                    comboBox1.Items.Clear();
                    comboBox2.Items.Clear();
                    con.Open();
                    SqlCommand cmd1 = new SqlCommand();
                    cmd1 = con.CreateCommand();
                    cmd1.CommandType = CommandType.Text;
                    cmd1.CommandText = "select * from MACHINES";
                    cmd1.ExecuteNonQuery();
                    DataTable dt1 = new DataTable();
                    SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
                    sda1.Fill(dt1);
                    foreach (DataRow dr in dt1.Rows)
                    {
                        comboBox1.Items.Add(dr["MACHINE_ID"].ToString());
                        comboBox2.Items.Add(dr["MACHINE_ID"].ToString());
                    }
                    comboBox2.Items[0] = "";
                    SqlDataAdapter sda = new SqlDataAdapter("SELECT DATE,MACHINE_ID as [MACHINE ID],ELEC_STOP as [ELECTRICAL STOPPAGE],MEC_STOP as [MECHANICAL STOPPAGE],SYS_STOP as [SYSTEM STOPPAGE],WORKING_Hrs as [EFFECTIVE WORKING HOURS],AVAILABILITY FROM MACHINES_WD ORDER BY DATE", con); 
                    DataTable dt = new DataTable();

                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;

                    foreach (DataGridViewColumn col in dataGridView1.Columns)
                    {
                        col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                        col.HeaderCell.Style.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Pixel);
                    }
                    //this.dataGridView1.Columns[0].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    //this.dataGridView1.Columns[2].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    //this.dataGridView1.Columns[6].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;


                    dataGridView1.Columns[0].Width = 100;
                    dataGridView1.Columns[1].Width = 160;
                    dataGridView1.Columns[2].Width = 155;
                    dataGridView1.Columns[3].Width = 160;
                    dataGridView1.Columns[4].Width = 128;
                    dataGridView1.Columns[5].Width = 185;
                    dataGridView1.Columns[6].Width = 110;
                    this.dataGridView1.Columns["DATE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    this.dataGridView1.Columns["MACHINE ID"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                    this.dataGridView1.Columns["SYSTEM STOPPAGE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    this.dataGridView1.Columns["ELECTRICAL STOPPAGE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    this.dataGridView1.Columns["MECHANICAL STOPPAGE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    this.dataGridView1.Columns["EFFECTIVE WORKING HOURS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    this.dataGridView1.Columns["AVAILABILITY"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;     

                    con.Close();
                    comboBox1.SelectedIndex = -1;
                    comboBox1.Text = "";
                    dateTimePicker1.Value = DateTime.Now;
                    textBox1.Text = "";
                    textBox2.Text = "";
                }
                catch (Exception EX)
                {
                    MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Cursor.Current = Cursors.Default;
                }
                finally
                {
                }


            }
        
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                Form3 frm3 = new Form3(label15.Text);
                frm3.Show();
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            finally
            {

            }
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
               
                if (checkedListBox1.SelectedIndex == -1)
                {
                    MessageBox.Show("PLEASE SELECT ANY ONE FILTER OPTION ", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    checkedListBox1.Focus();
                } 
               
                else if (checkedListBox1.SelectedIndex == 0)
                {
                    if (comboBox2.SelectedIndex == -1 | comboBox2.SelectedIndex == 0)
                    {
                        MessageBox.Show("PLEASE SELECT MACHINE_ID ", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        comboBox2.Focus();
                    }
                    else
                    {
                        SqlDataAdapter sda1 = new SqlDataAdapter("SELECT DATE,MACHINE_ID as [MACHINE ID],ELEC_STOP as [ELECTRICAL STOPPAGE],MEC_STOP as [MECHANICAL STOPPAGE],SYS_STOP as [SYSTEM STOPPAGE],WORKING_Hrs as [EFFECTIVE WORKING HOURS],AVAILABILITY FROM machines_wd where machine_id='" + comboBox2.SelectedItem.ToString() + "' ORDER BY DATE ", con);
                        DataTable dt1 = new DataTable();
                        sda1.Fill(dt1);
                       // dataGridView1.DataSource = dt1;                      

                         int totalhrs=0,ELH=0,MCH=0,SYSH=0,AVH=0;
                         int totalmins = 0,ELM=0,MCM=0,SYSM=0,AVM=0;
                        
                         foreach (DataRow dr in dt1.Rows)
                         {
                             string[] items = dr["EFFECTIVE WORKING HOURS"].ToString().Split(':');
                             totalhrs += int.Parse(items[0]);
                             totalmins += int.Parse(items[1]);
                             string[] items1 = dr["ELECTRICAL STOPPAGE"].ToString().Split(':');
                             ELH += int.Parse(items1[0]);
                             ELM += int.Parse(items1[1]);

                             string[] items2 = dr["MECHANICAL STOPPAGE"].ToString().Split(':');
                             MCH += int.Parse(items2[0]);
                             MCM += int.Parse(items2[1]);

                             string[] items3 = dr["SYSTEM STOPPAGE"].ToString().Split(':');
                             SYSH += int.Parse(items3[0]);
                             SYSM += int.Parse(items3[1]);

                             string[] items4 = dr["AVAILABILITY"].ToString().Split(':');
                             AVH += int.Parse(items4[0]);
                             AVM += int.Parse(items4[1]);
                            

                             
                         }
                         totalhrs += totalmins / 60;
                         totalmins = totalmins % 60;

                         ELH += ELM / 60;
                         ELM = ELM % 60;

                         MCH += MCM / 60;
                         MCM = MCM % 60;

                         SYSH += SYSM / 60;
                         SYSM = SYSM % 60;

                         AVH += AVM / 60;
                         AVM = AVM % 60;

                        // label11.Text = string.Format("{0:D2}:{1:D2}", totalhrs, totalmins);
                        string total = string.Format("{0:D2}:{1:D2}", totalhrs, totalmins);
                        string total1 = string.Format("{0:D2}:{1:D2}", ELH,ELM);
                        string total2 = string.Format("{0:D2}:{1:D2}", MCH,MCM);
                        string total3 = string.Format("{0:D2}:{1:D2}", SYSH,SYSM);
                        string total4 = string.Format("{0:D2}:{1:D2}", AVH,AVM);

                        DataRow dr1 = dt1.NewRow();
                        
                        dr1["MACHINE ID"] = "TOTAL HOURS =" ;
                        dr1["EFFECTIVE WORKING HOURS"] = total;
                        dr1["ELECTRICAL STOPPAGE"] = total1;
                        dr1["MECHANICAL STOPPAGE"] = total2;
                        dr1["SYSTEM STOPPAGE"] = total3;
                        dr1["AVAILABILITY"] = total4;
                        dt1.Rows.Add(dr1);

                        //DataRow dr2 = dt1.NewRow();
                        //dr2["MACHINE_ID"] = "ELE_S HOURS = " + total1;
                        //dt1.Rows.Add(dr2);

                        //DataRow dr3 = dt1.NewRow();
                        //dr3["MACHINE_ID"] = "MEC_S HOURS = " + total2;
                        //dt1.Rows.Add(dr3);

                        //DataRow dr4 = dt1.NewRow();
                        //dr4["MACHINE_ID"] = "SYS_S HOURS = " + total3;
                        //dt1.Rows.Add(dr4);

                        //DataRow dr5 = dt1.NewRow();
                        //dr5["MACHINE_ID"] = "AVAIL_HOURS = " + total4;
                        //dt1.Rows.Add(dr5);

                        dataGridView1.DataSource = dt1;

                        checkedListBox1.SelectedIndex = -1;                        
                        comboBox2.SelectedIndex = -1;
                        dateTimePicker3.Value = DateTime.Now;
                        dateTimePicker2.Value = DateTime.Now;
                    }
                }

                else if (checkedListBox1.SelectedIndex == 1)
                {
                    SqlDataAdapter sda1 = new SqlDataAdapter("SELECT DATE,MACHINE_ID as [MACHINE ID],ELEC_STOP as [ELECTRICAL STOPPAGE],MEC_STOP as [MECHANICAL STOPPAGE],SYS_STOP as [SYSTEM STOPPAGE],WORKING_Hrs as [EFFECTIVE WORKING HOURS],AVAILABILITY  FROM machines_wd  where date between '" + dateTimePicker2.Value.ToString("yyyy-MM-dd") + "' AND '" + dateTimePicker3.Value.ToString("yyyy-MM-dd") + "' ORDER BY DATE", con);
                    DataTable dt1 = new DataTable();
                    sda1.Fill(dt1);
                    int totalhrs = 0, ELH = 0, MCH = 0, SYSH = 0, AVH = 0;
                    int totalmins = 0, ELM = 0, MCM = 0, SYSM = 0, AVM = 0;

                    foreach (DataRow dr in dt1.Rows)
                    {
                        string[] items = dr["EFFECTIVE WORKING HOURS"].ToString().Split(':');
                        totalhrs += int.Parse(items[0]);
                        totalmins += int.Parse(items[1]);
                        string[] items1 = dr["ELECTRICAL STOPPAGE"].ToString().Split(':');
                        ELH += int.Parse(items1[0]);
                        ELM += int.Parse(items1[1]);

                        string[] items2 = dr["MECHANICAL STOPPAGE"].ToString().Split(':');
                        MCH += int.Parse(items2[0]);
                        MCM += int.Parse(items2[1]);

                        string[] items3 = dr["SYSTEM STOPPAGE"].ToString().Split(':');
                        SYSH += int.Parse(items3[0]);
                        SYSM += int.Parse(items3[1]);

                        string[] items4 = dr["AVAILABILITY"].ToString().Split(':');
                        AVH += int.Parse(items4[0]);
                        AVM += int.Parse(items4[1]);



                    }
                    totalhrs += totalmins / 60;
                    totalmins = totalmins % 60;

                    ELH += ELM / 60;
                    ELM = ELM % 60;

                    MCH += MCM / 60;
                    MCM = MCM % 60;

                    SYSH += SYSM / 60;
                    SYSM = SYSM % 60;

                    AVH += AVM / 60;
                    AVM = AVM % 60;

                    // label11.Text = string.Format("{0:D2}:{1:D2}", totalhrs, totalmins);
                    string total = string.Format("{0:D2}:{1:D2}", totalhrs, totalmins);
                    string total1 = string.Format("{0:D2}:{1:D2}", ELH, ELM);
                    string total2 = string.Format("{0:D2}:{1:D2}", MCH, MCM);
                    string total3 = string.Format("{0:D2}:{1:D2}", SYSH, SYSM);
                    string total4 = string.Format("{0:D2}:{1:D2}", AVH, AVM);

                    DataRow dr1 = dt1.NewRow();

                    dr1["MACHINE ID"] = "TOTAL HOURS =";
                    dr1["EFFECTIVE WORKING HOURS"] = total;
                    dr1["ELECTRICAL STOPPAGE"] = total1;
                    dr1["MECHANICAL STOPPAGE"] = total2;
                    dr1["SYSTEM STOPPAGE"] = total3;
                    dr1["AVAILABILITY"] = total4;
                    dt1.Rows.Add(dr1);

                    dataGridView1.DataSource = dt1;

                    checkedListBox1.SelectedIndex = -1;
                    comboBox2.SelectedIndex = -1;
                    dateTimePicker3.Value = DateTime.Now;
                    dateTimePicker2.Value = DateTime.Now;

                    

                }
                else if (checkedListBox1.SelectedIndex == 2)
                {
                    if (comboBox2.SelectedIndex == -1)
                    {
                        MessageBox.Show("PLEASE SELECT MACHINE_ID ", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        comboBox2.Focus();
                    }
                    else
                    {
                        SqlDataAdapter sda1 = new SqlDataAdapter("SELECT DATE,MACHINE_ID as [MACHINE ID],ELEC_STOP as [ELECTRICAL STOPPAGE],MEC_STOP as [MECHANICAL STOPPAGE],SYS_STOP as [SYSTEM STOPPAGE],WORKING_Hrs as [EFFECTIVE WORKING HOURS],AVAILABILITY  FROM machines_wd  where machine_id='" + comboBox2.SelectedItem.ToString() + "' and date between '" + dateTimePicker2.Value.ToString("yyyy-MM-dd") + "' AND '" + dateTimePicker3.Value.ToString("yyyy-MM-dd") + "' ORDER BY DATE", con);
                        DataTable dt1 = new DataTable();
                        sda1.Fill(dt1);
                        int totalhrs = 0, ELH = 0, MCH = 0, SYSH = 0, AVH = 0;
                        int totalmins = 0, ELM = 0, MCM = 0, SYSM = 0, AVM = 0;

                        foreach (DataRow dr in dt1.Rows)
                        {
                            string[] items = dr["EFFECTIVE WORKING HOURS"].ToString().Split(':');
                            totalhrs += int.Parse(items[0]);
                            totalmins += int.Parse(items[1]);
                            string[] items1 = dr["ELECTRICAL STOPPAGE"].ToString().Split(':');
                            ELH += int.Parse(items1[0]);
                            ELM += int.Parse(items1[1]);

                            string[] items2 = dr["MECHANICAL STOPPAGE"].ToString().Split(':');
                            MCH += int.Parse(items2[0]);
                            MCM += int.Parse(items2[1]);

                            string[] items3 = dr["SYSTEM STOPPAGE"].ToString().Split(':');
                            SYSH += int.Parse(items3[0]);
                            SYSM += int.Parse(items3[1]);

                            string[] items4 = dr["AVAILABILITY"].ToString().Split(':');
                            AVH += int.Parse(items4[0]);
                            AVM += int.Parse(items4[1]);



                        }
                        totalhrs += totalmins / 60;
                        totalmins = totalmins % 60;

                        ELH += ELM / 60;
                        ELM = ELM % 60;

                        MCH += MCM / 60;
                        MCM = MCM % 60;

                        SYSH += SYSM / 60;
                        SYSM = SYSM % 60;

                        AVH += AVM / 60;
                        AVM = AVM % 60;

                        // label11.Text = string.Format("{0:D2}:{1:D2}", totalhrs, totalmins);
                        string total = string.Format("{0:D2}:{1:D2}", totalhrs, totalmins);
                        string total1 = string.Format("{0:D2}:{1:D2}", ELH, ELM);
                        string total2 = string.Format("{0:D2}:{1:D2}", MCH, MCM);
                        string total3 = string.Format("{0:D2}:{1:D2}", SYSH, SYSM);
                        string total4 = string.Format("{0:D2}:{1:D2}", AVH, AVM);

                        DataRow dr1 = dt1.NewRow();

                        dr1["MACHINE ID"] = "TOTAL HOURS =";
                        dr1["EFFECTIVE WORKING HOURS"] = total;
                        dr1["ELECTRICAL STOPPAGE"] = total1;
                        dr1["MECHANICAL STOPPAGE"] = total2;
                        dr1["SYSTEM STOPPAGE"] = total3;
                        dr1["AVAILABILITY"] = total4;
                        dt1.Rows.Add(dr1);

                        dataGridView1.DataSource = dt1;

                        checkedListBox1.SelectedIndex = -1;
                        comboBox2.SelectedIndex = -1;
                        dateTimePicker3.Value = DateTime.Now;
                        dateTimePicker2.Value = DateTime.Now;
                    }
                }
                else
                {

                }
                Cursor.Current = Cursors.Default;
               
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }

            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }
       

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                Form3 frm3 = new Form3(label15.Text);
                frm3.Show();
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            finally
            {

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

            try
            {
                Cursor.Current = Cursors.WaitCursor;
               
                Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                app.Visible = true;
                app.Columns.ColumnWidth = 15;
               

               
                worksheet = workbook.Sheets["Sheet1"];
                worksheet = workbook.ActiveSheet;
                worksheet.Name = "MACHINE AVAILABILITY";
                

                for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)
                {
                    worksheet.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;
                }

                for (int i = 0; i <= dataGridView1.Rows.Count - 1; i++)
                {
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        worksheet.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                    }
                }
                Cursor.Current = Cursors.Default;
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
               Cursor.Current = Cursors.Default;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.CharacterCasing = CharacterCasing.Upper;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
          
        }

        private void tb_kd2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }

        private void cb1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                dateTimePicker1.Focus();
            }
        }

        private void dt4(object sender, KeyEventArgs e)
        {
            if (checkedListBox1.SelectedIndex == 2)
            {
                if (e.KeyCode == Keys.Enter)
                {
                    textBox2.Focus();
                }
            }
            //else if (checkedListBox1.SelectedIndex == 0)
            //{
            //    if (comboBox1.SelectedIndex == 0)
            //    {
            //        if (e.KeyCode == Keys.Enter)
            //        {
            //            textBox2.Focus();
            //        }
            //    }
            //    else
            //    {
            //        if (e.KeyCode == Keys.Enter)
            //        {
            //            button1.PerformClick();
            //        }
            //    }
            //}
            else
            {
                if (e.KeyCode == Keys.Enter)
                {
                    button1.PerformClick();
                }

            }
        }

        private void dt1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                dateTimePicker5.Focus();
            }
            
        }

        private void rectangleShape1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            //if (radioButton1.Checked == true)
            //{
            //    radioButton1.Checked = false;
            //}
        }

        private void rbclick(object sender, EventArgs e)
        {
            //if (radioButton1.Checked == false)
            //{
            //    radioButton1.Checked = true;
            //}
            //if (radioButton1.Checked == true)
            //{
            //    radioButton1.Checked = false;
            //}
            ////else
            //{
            //    radioButton1.Checked = false;
            //}

        }

        //private void checkedListBox2_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    ch
        //}

        private void checkedListBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (checkedListBox2.SelectedIndex == 2)
            {
                comboBox1.Enabled = false;
                dateTimePicker1.Enabled = false;
                dateTimePicker4.Enabled = false;
                dateTimePicker5.Enabled = false;
                dateTimePicker6.Enabled = false;
                dateTimePicker7.Enabled = false;
                dateTimePicker8.Enabled = false;
                label3.Visible = true;
                textBox2.Visible = true;
                textBox2.Focus();
            }
            else
            {

                comboBox1.Enabled = true;
                dateTimePicker1.Enabled = true;
                dateTimePicker4.Enabled = true;
                dateTimePicker5.Enabled = true;
                dateTimePicker6.Enabled = true;
                dateTimePicker7.Enabled = true;
                dateTimePicker8.Enabled = true;
                label3.Visible = false;
                textBox2.Visible = false;
                comboBox1.Focus();
            }
        }

        private void DT5(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                dateTimePicker6.Focus();
            }
        }

        private void DT6(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                dateTimePicker7.Focus();
            }
        }

        private void DT7(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                dateTimePicker8.Focus();
            }
        }

        private void DT8(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                dateTimePicker4.Focus();
            }
        }

        private void cb2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                dateTimePicker2.Focus();
            }

        }

        private void dt2(object sender, KeyEventArgs e)
        {
        }

        private void dt3(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button3.PerformClick();
            }
        }

        private void DT2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                dateTimePicker3.Focus();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

    }
}
