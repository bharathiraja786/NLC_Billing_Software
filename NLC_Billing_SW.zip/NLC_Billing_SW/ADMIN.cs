﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace NLC_SMS
{
    public partial class ADMIN : Form
    {
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["NLC_SMS.Properties.Settings.abbConnectionString"].ConnectionString);
      
        public ADMIN()
        {
            InitializeComponent();
        }

        private void ADMIN_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
            dataGridView1.DataSource = "";
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = ""+textBox1.Text+"";//SL_NO TO M_CODE
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
             }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
               
            }
            finally
            {
                con.Close();
                textBox1.Focus();
            }
        }

        private void TB1KD(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }
    }
}
