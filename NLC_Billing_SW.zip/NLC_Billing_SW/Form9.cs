﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace NLC_SMS
{
    public partial class Form9 : Form
    {
        //SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-7RUQB76;Initial Catalog=ABB;Integrated Security=True;Pooling=False");
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["NLC_SMS.Properties.Settings.abbConnectionString"].ConnectionString);
      
        public Form9()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                Cursor.Current = Cursors.WaitCursor;
                if (textBox1.Text != "")
                {
                    label2.Text = label2.Text + textBox1.Text;
                    con.Open();
                    SqlCommand cmd1 = con.CreateCommand();
                    cmd1.CommandType = CommandType.Text;
                    cmd1.CommandText = "select " + label2.Text + " from abb ";
                    cmd1.ExecuteNonQuery();
                    con.Close();


                    Form5 frm5 = new Form5(label2.Text);
                    frm5.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("PLEASE ENTER INVOICE_NUMBER", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox1.Focus();

                    /* , "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
          , "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
           MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);   */

                }
                Cursor.Current = Cursors.Default;
            }
            catch (Exception EX)
            {
                //MessageBox.Show("ERROR:" + EX.Message);
                MessageBox.Show("INVOICE NUMBER IS INVALID", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                label2.Text = "IVN_";
                textBox1.Text = "";
                Cursor.Current = Cursors.Default;
            }

            
            
        }

        private void Form9_Load(object sender, EventArgs e)
        {

        }

        private void TB_KD1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
            this.Hide();
            Form3 frm3 = new Form3("ADMIN");
            frm3.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.CharacterCasing = CharacterCasing.Upper;
        }
    }
}
