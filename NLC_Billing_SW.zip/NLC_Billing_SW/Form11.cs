﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace NLC_SMS
{
    public partial class Form11 : Form
    {
       // SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-7RUQB76;Initial Catalog=ABB;Integrated Security=True;Pooling=False");
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["NLC_SMS.Properties.Settings.abbConnectionString"].ConnectionString);
      
        public Form11()
        {
            InitializeComponent();
            /* , "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
         , "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
          MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);   */

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
               if (textBox3.Text == "")
                {
                    MessageBox.Show("PLEASE ENTER M_DESCRIPTION", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox3.Focus();
                }
                else if(textBox4.Text=="")
                {
                    MessageBox.Show("PLEASE ENTER UNIT", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox4.Focus();
                }
                else
                {           
               

                con.Open();
             
                SqlCommand cmd1 = con.CreateCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "select m_code from abb where m_code='" + textBox2.Text + "' ";
                cmd1.ExecuteNonQuery();
                string mcode = Convert.ToString(cmd1.ExecuteScalar());

                SqlCommand cmd2 = con.CreateCommand();
                cmd2.CommandType = CommandType.Text;
                cmd2.CommandText = "select material_description from abb where material_description='" + textBox3.Text + "' ";
                cmd2.ExecuteNonQuery();
                string mdes = Convert.ToString(cmd2.ExecuteScalar());


                if (textBox2.Text == "")
                {
                    textBox2.Text = textBox1.Text;
                }


               
                if(mcode == textBox2.Text)
                {
                    MessageBox.Show("M_CODE ALREADY EXISTS", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox2.Focus();
                }
                else if (mdes == textBox3.Text)
                {
                    MessageBox.Show("M_DESCRIPTION ALREADY EXISTS", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox3.Focus();
                }
                else
                {
                    SqlCommand cmd3 = con.CreateCommand();
                    cmd3.CommandType = CommandType.Text;
                    cmd3.CommandText = "insert into abb (sl_no,m_code,material_description,unit,received_qty,available_stock) values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "',0,0)";
                    //where material_description !='"+textBox3.Text+"' and sl_no !='"+textBox1.Text+"' and m_code !='"+textBox2.Text+"'
                    cmd3.ExecuteNonQuery();

                    MessageBox.Show("METERIAL INSERTED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                con.Close();
                Cursor.Current = Cursors.Default;
            }

            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
            con.Close();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox2.Focus();
           

           
                con.Open();
                SqlCommand cmd2 = con.CreateCommand();
                cmd2.CommandType = CommandType.Text;
                cmd2.CommandText = "select max(SL_NO) from abb";
                cmd2.ExecuteNonQuery();
                textBox1.Text = Convert.ToString(cmd2.ExecuteScalar());
                con.Close();

                double b;
                double.TryParse(textBox1.Text, out b);
                textBox1.Text = Convert.ToString(b + 1);
                Cursor.Current = Cursors.Default;
           

          

            }

        }

        private void Form11_Load(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd2 = con.CreateCommand();
                cmd2.CommandType = CommandType.Text;
                cmd2.CommandText = "select max(SL_NO) from abb";
                cmd2.ExecuteNonQuery();
                textBox1.Text = Convert.ToString(cmd2.ExecuteScalar());
                con.Close();

                
                double b;
                double.TryParse(textBox1.Text, out b);
                if (b < 1)
                {
                    textBox1.Text = "1";
                }
                else
                {
                    textBox1.Text = Convert.ToString(b + 1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
            this.Hide();
            Form3 FRM3=new Form3("ADMIN");
            FRM3.Show();
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
               
            }
        }

        private void tb_kd1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox2.Focus();
            }
        }

        private void tb_kd2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox3.Focus();
            }
        }

        private void tb_kd3(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox4.Focus();
            }
        }

        private void tb_kd4(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void rectangleShape1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.CharacterCasing = CharacterCasing.Upper;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            textBox3.CharacterCasing = CharacterCasing.Upper;
        }

       
    }
}
