﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace NLC_SMS
{
    public partial class Form2 : Form
    {
       // SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-7RUQB76;Initial Catalog=ABB;Integrated Security=True;Pooling=False");
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["NLC_SMS.Properties.Settings.abbConnectionString"].ConnectionString);
      
        
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd5 = con.CreateCommand();
                cmd5.CommandType = CommandType.Text;
                cmd5.CommandText = "update uhistory set ACTIONS+=', USER_REGISTERED' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd5.ExecuteNonQuery();
                con.Close();

                if (radioButton1.Checked == true)
                {
                    if (textBox1.Text == "")
                    {
                        MessageBox.Show("PLEASE ENTER USER_NAME", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        textBox1.Focus();
                    }
                    else if (textBox2.Text == "")
                    {
                        MessageBox.Show("PLEASE ENTER USER_ID", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        textBox2.Focus();
                    }
                    else if (textBox3.Text == "")
                    {
                        MessageBox.Show("PLEASE ENTER PASSWORD", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        textBox3.Focus();
                    }
                    else if (textBox4.Text == "")
                    {
                        MessageBox.Show("PLEASE ENTER CONFORM_PASSWORD", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        textBox4.Focus();
                    }
                    else
                    {
                        if (textBox3.Text == textBox4.Text)
                        {
                            // SqlConnection con = new SqlConnection(@"Data Source=desktop-7ruqb76;Initial Catalog=master;Integrated Security=True");
                            con.Open();
                            SqlCommand cmd = con.CreateCommand();
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandText = "insert into login values('" + textBox1.Text + "','" + textBox3.Text + "','" + textBox2.Text + "')";
                            cmd.ExecuteNonQuery();
                            con.Close();
                            MessageBox.Show("USER REGISTERED SUCCESSFULLY","MESSAGE",MessageBoxButtons.OK,MessageBoxIcon.Information);

                            textBox1.Text = "";
                            textBox2.Text = "";
                            textBox3.Text = "";
                            textBox4.Text = "";
                        }
                        else
                        {
                            MessageBox.Show("PASSWORD MISMATCH", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            textBox4.Focus();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("PLEASE SELECT REGISTRATION OPTION", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
                Form3 frm1 = new Form3("ADMIN");
                frm1.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { }
        }

        private void tb_kd(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    textBox2.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { }
        }

        private void tb_kd2(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    textBox3.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { }
        }

        private void tb_kd3(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    textBox4.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { }
        }

        private void tb_kd4(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    button1.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.CharacterCasing = CharacterCasing.Upper;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.CharacterCasing = CharacterCasing.Upper;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

            try
            {
                Cursor.Current = Cursors.WaitCursor;
                comboBox2.Items.Clear();
                con.Open();
                SqlCommand cmd1 = new SqlCommand();
                cmd1 = con.CreateCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "select USER_ID from LOGIN  where (USER_ID!='ADMIN' and USER_ID!= 'ADVANCED' and USER_ID!= 'CONNECTIONSTRING')";
                cmd1.ExecuteNonQuery();
                DataTable dt1 = new DataTable();
                SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
                sda1.Fill(dt1);
                foreach (DataRow dr in dt1.Rows)
                {
                    comboBox2.Items.Add(dr["USER_ID"].ToString());
                }
                Cursor.Current = Cursors.Default;
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;

            }
            finally
            {
                con.Close();
                comboBox1.Items.Clear();
                Cursor.Current = Cursors.Default;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;

               
                if (radioButton3.Checked == true)
                {
                    if(comboBox2.SelectedIndex!=-1)
                    {

                        if (MessageBox.Show("ARE YOU SURE TO DELETE THIS USER '" + comboBox2.Text + "'", "CONFORMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            con.Open();
                            SqlCommand cmd1 = new SqlCommand();
                            cmd1 = con.CreateCommand();
                            cmd1.CommandType = CommandType.Text;
                            cmd1.CommandText = " delete from LOGIN where USER_ID='" + comboBox2.SelectedItem.ToString() + "'";
                            cmd1.ExecuteNonQuery();
                            con.Close();
                            MessageBox.Show("USER DELETED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            con.Open();
                            SqlCommand cmd5 = con.CreateCommand();
                            cmd5.CommandType = CommandType.Text;
                            cmd5.CommandText = "update uhistory set ACTIONS+=', USER_DELETED' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                            cmd5.ExecuteNonQuery();
                            con.Close();


                            comboBox1.Items.Clear();
                            con.Open();
                            SqlCommand cmd = new SqlCommand();
                            cmd = con.CreateCommand();
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandText = "select USER_ID from LOGIN  where (USER_ID!='ADMIN' and USER_ID!= 'ADVANCED')";
                            cmd.ExecuteNonQuery();
                            DataTable dt1 = new DataTable();
                            SqlDataAdapter sda1 = new SqlDataAdapter(cmd);
                            sda1.Fill(dt1);
                            foreach (DataRow dr in dt1.Rows)
                            {
                                comboBox1.Items.Add(dr["USER_ID"].ToString());
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("PLEASE SELECT ANY ONE USER","WARNING",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    }
                        Cursor.Current = Cursors.Default;
                   
                }
                else
                {
                    MessageBox.Show("PLEASE SELECT REMOVE OPTION", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                comboBox1.Text = "";
                Cursor.Current = Cursors.Default;

            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd5 = con.CreateCommand();
                cmd5.CommandType = CommandType.Text;
                cmd5.CommandText = "update uhistory set ACTIONS+=', USER_PWD_UPDATED' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd5.ExecuteNonQuery();
                con.Close();

                if (radioButton2.Checked == true)
                {
                    if (comboBox1.SelectedIndex == -1)
                    {
                        MessageBox.Show("PLEASE SELECT USER", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        comboBox1.Focus();
                    }
                    else if (textBox5.Text == "")
                    {
                        MessageBox.Show("PLEASE ENTER NEW_PASSWORD", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        textBox5.Focus();
                    }

                    else
                    {

                        con.Open();
                        SqlCommand cmd = con.CreateCommand();
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "update login set pwd='" + textBox5.Text + "' where user_id='" + comboBox1.SelectedItem.ToString() + "' ";
                        cmd.ExecuteNonQuery();
                        con.Close();
                        MessageBox.Show("PASSWORD UPDATED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);


                    }
                }
                else
                {
                    MessageBox.Show("PLEASE SELECT UPDATE OPTION", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                textBox5.Text = "";
                comboBox1.Text = "";
                Cursor.Current = Cursors.Default;
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

            try
            {
                Cursor.Current = Cursors.WaitCursor;
                comboBox1.Items.Clear();
                con.Open();
                SqlCommand cmd1 = new SqlCommand();
                cmd1 = con.CreateCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "select USER_ID from LOGIN  where (USER_ID!='ADMIN' and USER_ID!= 'ADVANCED' and USER_ID!= 'CONNECTIONSTRING')";
                cmd1.ExecuteNonQuery();
                DataTable dt1 = new DataTable();
                SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
                sda1.Fill(dt1);
                foreach (DataRow dr in dt1.Rows)
                {
                    comboBox1.Items.Add(dr["USER_ID"].ToString());
                }
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;

            }
            finally
            {
                comboBox2.Items.Clear();
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void cbkd1(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    textBox5.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { }
        }

        private void tbkd5(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    button3.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void CMKD2(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    button6.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
                Form3 frm1 = new Form3("ADMIN");
                frm1.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
                Form3 frm1 = new Form3("ADMIN");
                frm1.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                comboBox1.Items.Clear();
                comboBox2.Items.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { }
        }
    }
}
