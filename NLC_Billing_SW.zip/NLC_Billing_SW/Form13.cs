﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace NLC_SMS
{
    public partial class Form13 : Form
    {
        //SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-7RUQB76;Initial Catalog=ABB;Integrated Security=True;Pooling=False");
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["NLC_SMS.Properties.Settings.abbConnectionString"].ConnectionString);
      
       
        public Form13()
        {
            InitializeComponent();

            /* , "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        , "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
         MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);   */
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set ACTIONS+=', ADMIN_PWD_CHANGED' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
                if (textBox1.Text == "")
                {
                    MessageBox.Show("PLEASE ENTER OLD_PASSWORD", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox1.Focus();
                }
                else if (textBox2.Text == "")
                {
                    MessageBox.Show("PLEASE ENTER NEW_PASSWORD", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox2.Focus();
                }
                else if (textBox3.Text == "")
                {
                    MessageBox.Show("PLEASE ENTER CONFORM_PASSWORD", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox3.Focus();
                }
               
                else
                {
                    if (textBox2.Text == textBox3.Text)
                    {
                        con.Open();
                        SqlCommand cmd7 = con.CreateCommand();
                        cmd7.CommandType = CommandType.Text;
                        cmd7.CommandText = "update login set pwd='" + textBox2.Text + "' where user_id='ADMIN' ";
                        cmd7.ExecuteNonQuery();
                        con.Close();
                        MessageBox.Show("PASSWORD UPDATED SUCCESSFULLY", "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        con.Open();
                        SqlCommand cmd1 = con.CreateCommand();
                        cmd1.CommandType = CommandType.Text;
                        cmd1.CommandText = "update uhistory set LOGOUT_DT='" + dateTimePicker1.Value.ToString("yyyy-MM-dd HH:mm:ss") + "' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                        cmd1.ExecuteNonQuery();
                        con.Close();

                        this.Hide();
                        Form1 frm = new Form1();
                        frm.Show();
                    }
                    else
                    {
                        MessageBox.Show("PASSWORD MISMATCH", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        textBox3.Focus();
                    }
                }
                Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally 
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;

               
                    this.Hide();
                    Form3 frm3 = new Form3("ADMIN");
                    frm3.Show();
               
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                con.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void tb_kd1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox2.Focus();
            }
        }

        private void tb_kd2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox3.Focus();
            }
        }

        private void tb3_kd3(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form13_Load(object sender, EventArgs e)
        {

        }
    }
}
