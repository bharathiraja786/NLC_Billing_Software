﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data.Sql;
using System.Configuration;

namespace NLC_SMS
{
    public partial class Form8 : Form
    {
       // SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-7RUQB76;Initial Catalog=ABB;Integrated Security=True;Pooling=False"); 
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["NLC_SMS.Properties.Settings.abbConnectionString"].ConnectionString);
      
        public Form8(string value)
        {
            InitializeComponent();
            label6.Text = value;
            /* , "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
          , "MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Information);
           MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);   */

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                Form3 frm3 = new Form3(label6.Text);
                frm3.Show();
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            finally
            {

            }
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                SqlDataAdapter sda = new SqlDataAdapter("select R_DATE as [DATE],EMP_NAME as [EMPLOYEE NAME],MACHINE_ID as [MACHINE ID],M_CODE as [MATERIAL CODE],M_DESCRIPTION as [MATERIAL DESCRIPTION],M_QUANTITY as [MATERIAL QUANTITY],TRANSACTION_TYPE as [TRANSACTION TYPE] from HISTORY ORDER BY R_DATE", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
                foreach (DataGridViewColumn col in dataGridView1.Columns)
                {
                    col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    col.HeaderCell.Style.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Pixel);
                }
                dataGridView1.Columns[0].Width =100;
                dataGridView1.Columns[1].Width = 150;
                dataGridView1.Columns[5].Width = 100;
                dataGridView1.Columns[3].Width = 100;
                dataGridView1.Columns[4].Width = 320;
                dataGridView1.Columns[2].Width = 130;               
                dataGridView1.Columns[6].Width = 107;

                this.dataGridView1.Columns["MACHINE ID"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                this.dataGridView1.Columns["MATERIAL CODE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                this.dataGridView1.Columns["MATERIAL QUANTITY"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                this.dataGridView1.Columns["DATE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                this.dataGridView1.Columns["TRANSACTION TYPE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

 

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
    
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update uhistory set ACTIONS+=', HISTORY_TO_EXCEL' where LOGIN_DT=(select MAX(LOGIN_DT) from uhistory) ";// set user_id = role;
                cmd.ExecuteNonQuery();
                con.Close();
                Cursor.Current = Cursors.WaitCursor;
                    Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();                    
                    Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);                   
                    Microsoft.Office.Interop.Excel._Worksheet worksheet = null;                    
                    app.Visible = true;
                    app.Columns.ColumnWidth = 15;
                     
                    worksheet = workbook.Sheets["Sheet1"];
                    worksheet = workbook.ActiveSheet;                     
                    worksheet.Name = "TRANSACTIONS";
                   
                    for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)
                    {
                        worksheet.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;
                    }
                   
                    for (int i = 0; i <= dataGridView1.Rows.Count - 1; i++)
                    {
                        for (int j = 0; j < dataGridView1.Columns.Count; j++)
                        {
                            worksheet.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                        }
                    }
                    Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                if (checkedListBox1.SelectedIndex == 0)
                {
                    /*dateTimePicker1.MaxDate = DateTime.MaxValue;
                    dateTimePicker2.MaxDate = DateTime.MaxValue;*/

                    SqlDataAdapter sda = new SqlDataAdapter("select R_DATE as [DATE],EMP_NAME as [EMPLOYEE NAME],MACHINE_ID as [MACHINE ID],M_CODE as [MATERIAL CODE],M_DESCRIPTION as [MATERIAL DESCRIPTION],M_QUANTITY as [MATERIAL QUANTITY],TRANSACTION_TYPE as [TRANSACTION TYPE] from HISTORY WHERE R_DATE BETWEEN '" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "' and '" + dateTimePicker2.Value.ToString("yyyy-MM-dd") + "'order by R_DATE ", con);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;
                    checkedListBox1.SelectedIndex = -1;
                    dateTimePicker1.Value = DateTime.Now;
                    dateTimePicker2.Value = DateTime.Now;
                    comboBox1.SelectedIndex = -1;
                }
                else if (checkedListBox1.SelectedIndex == 2)
                {
                    if (comboBox1.SelectedIndex != -1)
                    {

                        SqlDataAdapter sda = new SqlDataAdapter("select R_DATE as [DATE],EMP_NAME as [EMPLOYEE NAME],MACHINE_ID as [MACHINE ID],M_CODE as [MATERIAL CODE],M_DESCRIPTION as [MATERIAL DESCRIPTION],M_QUANTITY as [MATERIAL QUANTITY],TRANSACTION_TYPE as [TRANSACTION TYPE] from HISTORY WHERE (R_DATE BETWEEN '" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "' and '" + dateTimePicker2.Value.ToString("yyyy-MM-dd") + "') AND TRANSACTION_TYPE='" + comboBox1.SelectedItem.ToString() + "' order by R_DATE  ", con);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        dataGridView1.DataSource = dt;
                        checkedListBox1.SelectedIndex = -1;
                        dateTimePicker1.Value = DateTime.Now;
                        dateTimePicker2.Value = DateTime.Now;
                        comboBox1.SelectedIndex = -1;
                    }
                    else
                    {
                        MessageBox.Show("PLEASE SELECT TRANSACTION TYPE", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        comboBox1.Focus();
                    }
                }
                else if (checkedListBox1.SelectedIndex == 1)
                {
                    if(comboBox1.SelectedIndex!=-1)
                    {
                        SqlDataAdapter sda = new SqlDataAdapter("select R_DATE as [DATE],EMP_NAME as [EMPLOYEE NAME],MACHINE_ID as [MACHINE ID],M_CODE as [MATERIAL CODE],M_DESCRIPTION as [MATERIAL DESCRIPTION],M_QUANTITY as [MATERIAL QUANTITY],TRANSACTION_TYPE as [TRANSACTION TYPE] from HISTORY WHERE TRANSACTION_TYPE='" + comboBox1.SelectedItem.ToString() + "' ORDER BY R_DATE ", con);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;
                    checkedListBox1.SelectedIndex = -1;
                    dateTimePicker1.Value = DateTime.Now;
                    dateTimePicker2.Value = DateTime.Now;
                    comboBox1.SelectedIndex = -1;
                    }
                    else
                        MessageBox.Show("PLEASE SELECT TRANSACTION TYPE", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }
                else
                {
                    MessageBox.Show("PLEASE SELECT ANY ONE FILTER OPTION", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    checkedListBox1.SelectedIndex = -1;
                    dateTimePicker1.Value = DateTime.Now;
                    dateTimePicker2.Value = DateTime.Now;
                    comboBox1.SelectedIndex = -1;
                }
                Cursor.Current = Cursors.WaitCursor;
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
               Cursor.Current = Cursors.Default;
            }
            finally
            {
                checkedListBox1.SelectedIndex = -1;
                dateTimePicker1.Value = DateTime.Now;
                dateTimePicker2.Value = DateTime.Now;
                comboBox1.SelectedIndex = -1;
                Cursor.Current = Cursors.Default;
            }

        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                SqlDataAdapter sda = new SqlDataAdapter("select R_DATE as [DATE],EMP_NAME as [EMPLOYEE NAME],MACHINE_ID as [MACHINE ID],M_CODE as [MATERIAL CODE],M_DESCRIPTION as [MATERIAL DESCRIPTION],M_QUANTITY as [MATERIAL QUANTITY],TRANSACTION_TYPE as [TRANSACTION TYPE] from HISTORY", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
                Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                checkedListBox1.SelectedIndex = -1;
                comboBox1.SelectedIndex = -1;
                dateTimePicker1.Value = DateTime.Now;
                dateTimePicker2.Value = DateTime.Now;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

       
        
    }
}
